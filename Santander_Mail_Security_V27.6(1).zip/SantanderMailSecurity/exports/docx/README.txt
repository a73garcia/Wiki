Los procedimientos Word generados desde la Wiki se almacenan en esta carpeta.
