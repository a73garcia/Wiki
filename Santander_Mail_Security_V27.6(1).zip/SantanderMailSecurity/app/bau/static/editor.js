function editorFor(button) {
  const toolbar = button.closest('.toolbar');
  return toolbar ? document.getElementById(toolbar.dataset.target) : null;
}

function emitInput(textarea) {
  textarea.dispatchEvent(new Event('input', {bubbles: true}));
}

function insertText(textarea, open, close = '', mode = 'wrap') {
  const start = textarea.selectionStart;
  const end = textarea.selectionEnd;
  const selected = textarea.value.slice(start, end);
  let value = '';

  if (mode === 'insert') value = open;
  else if (mode === 'code') value = `\n\n\`\`\`${open}\n${selected}\n\`\`\`\n\n`;
  else value = open + selected + close;

  textarea.setRangeText(value, start, end, 'end');
  textarea.focus();
  emitInput(textarea);
}

function insertHeading(textarea, level = 2) {
  const marks = '='.repeat(Math.max(2, Math.min(6, Number(level) || 2)));
  const value = textarea.value;
  const selectionStart = textarea.selectionStart;
  const selectionEnd = textarea.selectionEnd;
  const selected = value.slice(selectionStart, selectionEnd).trim() || 'Título';

  const lineStart = value.lastIndexOf('\n', Math.max(0, selectionStart - 1)) + 1;
  let lineEnd = value.indexOf('\n', selectionEnd);
  if (lineEnd < 0) lineEnd = value.length;

  const heading = `${marks} ${selected} ${marks}`;
  textarea.setRangeText(heading, lineStart, lineEnd, 'end');

  const titleStart = lineStart + marks.length + 1;
  textarea.setSelectionRange(titleStart, titleStart + selected.length);
  textarea.focus();
  emitInput(textarea);
}

function indent(textarea, remove = false) {
  const value = textarea.value;
  const originalStart = textarea.selectionStart;
  const originalEnd = textarea.selectionEnd;
  const lineStart = value.lastIndexOf('\n', Math.max(0, originalStart - 1)) + 1;
  let lineEnd = value.indexOf('\n', originalEnd);
  if (lineEnd < 0) lineEnd = value.length;

  const lines = value.slice(lineStart, lineEnd).split('\n');
  let firstDelta = 0;
  let totalDelta = 0;

  const changed = lines.map((line, index) => {
    if (!remove) {
      if (index === 0) firstDelta = 4;
      totalDelta += 4;
      return '    ' + line;
    }

    const match = line.match(/^(\t| {1,4})/);
    const count = match ? match[0].length : 0;
    if (index === 0) firstDelta = -count;
    totalDelta -= count;
    return line.slice(count);
  }).join('\n');

  textarea.setRangeText(changed, lineStart, lineEnd, 'select');
  textarea.selectionStart = Math.max(lineStart, originalStart + firstDelta);
  textarea.selectionEnd = Math.max(textarea.selectionStart, originalEnd + totalDelta);
  textarea.focus();
  emitInput(textarea);
}

document.addEventListener('click', async event => {
  const button = event.target.closest('.toolbar button');
  if (!button) return;

  const textarea = editorFor(button);
  if (!textarea) return;

  if (button.dataset.heading !== undefined) {
    insertHeading(textarea, button.dataset.heading);
  } else if (button.dataset.insert !== undefined) {
    insertText(textarea, button.dataset.insert, '', 'insert');
  } else if (button.dataset.wrap !== undefined) {
    insertText(textarea, button.dataset.wrap, button.dataset.wrap);
  } else if (button.dataset.wrapOpen !== undefined) {
    insertText(textarea, button.dataset.wrapOpen, button.dataset.wrapClose || '');
  } else if (button.dataset.code !== undefined) {
    insertText(textarea, button.dataset.code, '', 'code');
  } else if (button.dataset.indent !== undefined) {
    indent(textarea, false);
  } else if (button.dataset.outdent !== undefined) {
    indent(textarea, true);
  } else if (button.dataset.image !== undefined) {
    const input = document.querySelector(`.bau-image-input[data-editor="${textarea.id}"]`);
    if (input) {
      input.value = '';
      input.click();
    }
  }
});

document.addEventListener('keydown', event => {
  const textarea = event.target;
  if (event.key !== 'Tab' || textarea.tagName !== 'TEXTAREA') return;

  event.preventDefault();
  event.stopImmediatePropagation();
  indent(textarea, event.shiftKey);
}, true);

document.addEventListener('change', async event => {
  const input = event.target.closest('.bau-image-input');
  if (!input || !input.files?.[0]) return;

  const textarea = document.getElementById(input.dataset.editor);
  if (!textarea) return;

  const status = document.querySelector(`[data-status="${textarea.id}"]`);
  if (status) status.textContent = 'Subiendo imagen…';

  const form = new FormData();
  form.append('image', input.files[0]);

  try {
    const response = await fetch('/upload-image', {method: 'POST', body: form});
    const result = await response.json();

    if (!response.ok || !result.ok) {
      throw new Error(result.error || 'No se pudo subir la imagen.');
    }

    const name = input.files[0].name
      .replace(/\.[^.]+$/, '')
      .replace(/[-_]+/g, ' ');

    const position = textarea.selectionStart;
    textarea.setRangeText(
      `\n\n[[imagen:${result.filename}|${name}]]\n\n`,
      position,
      position,
      'end'
    );
    textarea.focus();
    emitInput(textarea);

    if (status) status.textContent = 'Imagen insertada.';
  } catch (error) {
    if (status) status.textContent = error.message || 'No se pudo subir la imagen.';
  }
});
