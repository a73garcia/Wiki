PLANTILLAS WORD

La plantilla predeterminada es:
Plantilla_procedimientos.docx

Puede abrirse, modificarse o sustituirse por otra conservando el mismo nombre.
Debe conservar estos marcadores:
{{TITLE}}
{{VERSION}}
{{DATE}}
{{AUTHOR}}
{{REVISION_DESCRIPTION}}
{{WIKI_INDEX}}
{{WIKI_CONTENT}}

La exportación V22 interpreta el contenido Wiki y crea elementos Word editables:
- # / ## / ###: títulos Word con el formato corporativo solicitado.
- **negrita**, *cursiva*, ~~tachado~~ y `código en línea`.
- [texto](URL): hipervínculo pulsable.
- Listas y sublistas: sangrías reales.
- Tablas Markdown: tablas Word.
- ```lenguaje: bloque de código con coloreado básico.
- ```correo o ```email: Aptos 9 pt cursiva.
- > texto: cita.
- ---: separador.
