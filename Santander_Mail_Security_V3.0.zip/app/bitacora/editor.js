function editorFor(button){
  const bar=button.closest('.toolbar');
  return bar ? document.getElementById(bar.dataset.target) : null;
}

function notifyInput(textarea){
  textarea.dispatchEvent(new Event('input',{bubbles:true}));
}

function insertText(textarea,open,close='',mode='wrap'){
  const start=textarea.selectionStart;
  const end=textarea.selectionEnd;
  const selected=textarea.value.slice(start,end);
  let value='';
  if(mode==='insert') value=open;
  else if(mode==='code') value=`\n\n\`\`\`${open}\n${selected}\n\`\`\`\n\n`;
  else value=open+selected+close;
  textarea.setRangeText(value,start,end,'end');
  textarea.focus();
  notifyInput(textarea);
}

function insertHeading(textarea,level=2){
  const marks='='.repeat(Math.max(2,Math.min(6,Number(level)||2)));
  const value=textarea.value;
  const start=textarea.selectionStart;
  const end=textarea.selectionEnd;
  const selected=value.slice(start,end).trim() || 'Título';

  const lineStart=value.lastIndexOf('\n',Math.max(0,start-1))+1;
  let lineEnd=value.indexOf('\n',end);
  if(lineEnd<0) lineEnd=value.length;

  const prefix=lineStart>0 && value[lineStart-1] !== '\n' ? '\n' : '';
  const suffix=lineEnd<value.length && value[lineEnd] !== '\n' ? '\n' : '';
  const heading=`${prefix}${marks} ${selected} ${marks}${suffix}`;

  textarea.setRangeText(heading,lineStart,lineEnd,'end');
  const titleStart=lineStart+prefix.length+marks.length+1;
  textarea.setSelectionRange(titleStart,titleStart+selected.length);
  textarea.focus();
  notifyInput(textarea);
}

function indent(textarea,remove=false){
  const value=textarea.value;
  const originalStart=textarea.selectionStart;
  const originalEnd=textarea.selectionEnd;
  const lineStart=value.lastIndexOf('\n',Math.max(0,originalStart-1))+1;
  let lineEnd=value.indexOf('\n',originalEnd);
  if(lineEnd<0) lineEnd=value.length;

  const block=value.slice(lineStart,lineEnd);
  const lines=block.split('\n');
  let firstDelta=0;
  let totalDelta=0;

  const changed=lines.map((line,index)=>{
    if(!remove){
      if(index===0) firstDelta=4;
      totalDelta+=4;
      return '    '+line;
    }
    const match=line.match(/^(\t| {1,4})/);
    const count=match ? match[0].length : 0;
    if(index===0) firstDelta=-count;
    totalDelta-=count;
    return line.slice(count);
  }).join('\n');

  textarea.setRangeText(changed,lineStart,lineEnd,'select');
  textarea.selectionStart=Math.max(lineStart,originalStart+firstDelta);
  textarea.selectionEnd=Math.max(textarea.selectionStart,originalEnd+totalDelta);
  textarea.focus();
  notifyInput(textarea);
}

document.addEventListener('click',async event=>{
  const button=event.target.closest('.toolbar button');
  if(!button)return;
  const textarea=editorFor(button);
  if(!textarea)return;

  if(button.dataset.heading!==undefined) insertHeading(textarea,button.dataset.heading);
  else if(button.dataset.communication!==undefined){
    const type=button.dataset.communication||'correo';
    const snippets={
      correo:'\n\n::: correo Correo\nPara: \nCC: \nCCO: \nAsunto: \n\nEscriba aquí el cuerpo del correo.\n::: endcorreo\n\n',
      caso:'\n\n::: caso Caso\nTítulo: \n\nEscriba aquí el cuerpo del caso.\n::: endcaso\n\n',
      respuesta:'\n\n::: respuesta Respuesta\nEscriba aquí el texto de la respuesta.\n::: endrespuesta\n\n'
    };
    insertText(textarea,snippets[type]||snippets.correo,'','insert');
    const menu=button.closest('details'); if(menu)menu.open=false;
  }
  else if(button.dataset.notice!==undefined){
    const kind=button.dataset.notice||'nota';
    const labels={nota:'Escriba aquí la nota...',advertencia:'Escriba aquí la advertencia...',informacion:'Escriba aquí la información...'};
    insertText(textarea,`\n\n!!! ${kind}:\n\n${labels[kind]||'Escriba aquí...'}\n\n!!!\n\n`,'','insert');
    const menu=button.closest('details'); if(menu)menu.open=false;
  }
  else if(button.dataset.insert!==undefined) insertText(textarea,button.dataset.insert,'','insert');
  else if(button.dataset.wrap!==undefined) insertText(textarea,button.dataset.wrap,button.dataset.wrap);
  else if(button.dataset.wrapOpen!==undefined) insertText(textarea,button.dataset.wrapOpen,button.dataset.wrapClose||'');
  else if(button.dataset.code!==undefined){ insertText(textarea,button.dataset.code,'','code'); const menu=button.closest('details'); if(menu)menu.open=false; }
  else if(button.dataset.indent!==undefined) indent(textarea,false);
  else if(button.dataset.outdent!==undefined) indent(textarea,true);
  else if(button.dataset.image){
    const input=document.querySelector(`.bau-image-input[data-editor="${textarea.id}"]`);
    if(input){input.value='';input.click();}
  }
});

document.addEventListener('keydown',event=>{
  const textarea=event.target;
  if(event.key!=='Tab'||textarea.tagName!=='TEXTAREA')return;
  event.preventDefault();
  indent(textarea,event.shiftKey);
});

document.addEventListener('change',async event=>{
  const input=event.target.closest('.bau-image-input');
  if(!input||!input.files?.[0])return;
  const textarea=document.getElementById(input.dataset.editor);
  if(!textarea)return;
  const status=document.querySelector(`[data-status="${textarea.id}"]`);
  if(status)status.textContent='Subiendo imagen…';
  const form=new FormData();
  form.append('image',input.files[0]);
  try{
    const response=await fetch('/upload-image',{method:'POST',body:form});
    const result=await response.json();
    if(!response.ok||!result.ok)throw new Error(result.error||'No se pudo subir la imagen.');
    const name=input.files[0].name.replace(/\.[^.]+$/,'').replace(/[-_]+/g,' ');
    const pos=textarea.selectionStart;
    textarea.setRangeText(`\n\n[[imagen:${result.filename}|${name}]]\n\n`,pos,pos,'end');
    textarea.focus();
    notifyInput(textarea);
    if(status)status.textContent='Imagen insertada.';
  }catch(error){
    if(status)status.textContent=error.message;
  }
});
