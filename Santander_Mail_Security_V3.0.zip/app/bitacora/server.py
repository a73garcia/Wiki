from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs, quote
from pathlib import Path
from datetime import datetime
import os, json, html, re, uuid, mimetypes

CORPORATE_THEME_CSS = r""":root {
  --santander-red:#EC0000;
  --santander-red-dark:#C00000;
  --santander-red-deep:#990000;
  --santander-red-soft:#FDECEC;
  --santander-coral:#FF5A5F;
  --santander-orange:#F57C00;
  --santander-black:#111111;
  --santander-text:#2D2D2D;
  --santander-grey-700:#5B5B5B;
  --santander-grey-500:#8A8A8A;
  --santander-grey-300:#C9C9C9;
  --santander-grey-200:#E5E5E5;
  --santander-grey-100:#F2F2F2;
  --santander-bg:#F7F7F7;
  --santander-white:#FFFFFF;
  --brand-font:"Santander Headline","Segoe UI",Arial,sans-serif;
  --body-font:"Santander Headline","Segoe UI",Arial,sans-serif;
}
*{box-sizing:border-box}
html,body{font-family:var(--body-font)!important}
body{background:var(--santander-bg)!important;color:var(--santander-text)!important}
header{
  background:linear-gradient(105deg,var(--santander-red-dark),var(--santander-red))!important;
  color:#fff!important;border-bottom:0!important;box-shadow:0 3px 12px rgba(80,0,0,.18)!important;
}
.brand{font-family:var(--brand-font)!important;font-weight:600!important;letter-spacing:.1px!important;display:flex!important;align-items:center!important;gap:12px!important}
.brand::before{
  content:"";display:inline-block;width:36px;height:34px;flex:0 0 36px;
  background-image:url("/corporate-logo.png");
  background-size:contain;background-position:center;background-repeat:no-repeat;
  filter:brightness(0) invert(1);
}
.shell aside,aside{background:#fff!important;border-right:1px solid var(--santander-grey-200)!important}
aside nav a,nav a{color:#3c3c3c!important;border-radius:6px!important;transition:.15s ease!important}
aside nav a:hover,nav a:hover{background:var(--santander-red-soft)!important;color:var(--santander-red-dark)!important}
aside nav a.active,nav a.active{
  background:var(--santander-red-soft)!important;color:var(--santander-red-dark)!important;
  border-left:4px solid var(--santander-red)!important;font-weight:700!important;
}
main h1,main h2,.page-title{font-family:var(--brand-font)!important;color:var(--santander-red-dark)!important}
main h3{font-family:var(--brand-font)!important;color:var(--santander-black)!important}
a{color:var(--santander-red-dark)}
a:hover{color:var(--santander-red)}
.btn,.button,button,input[type=submit],input[type=button]{
  font-family:var(--body-font)!important;border-radius:6px!important;box-shadow:none!important;
}
.btn.primary,.btn-primary,.button-primary,button.primary,input[type=submit]{
  background:var(--santander-red)!important;border-color:var(--santander-red)!important;color:#fff!important;
}
.btn.primary:hover,.btn-primary:hover,button.primary:hover,input[type=submit]:hover{
  background:var(--santander-red-dark)!important;border-color:var(--santander-red-dark)!important;
}
.btn:not(.primary),button:not(.primary){
  background:#fff!important;border-color:var(--santander-grey-300)!important;color:var(--santander-text)!important;
}
.card,.panel,.widget,.stat,.tile,.project-card,.task-card,.wiki-card,.bau-card{
  background:#fff!important;border:1px solid var(--santander-grey-200)!important;
  border-radius:10px!important;box-shadow:0 2px 8px rgba(0,0,0,.045)!important;
}
table{background:#fff!important;border-color:var(--santander-grey-200)!important}
thead th,table th{background:var(--santander-red-dark)!important;color:#fff!important;border-color:var(--santander-red-dark)!important}
tbody tr:nth-child(even){background:#FAFAFA!important}
input,select,textarea{
  font-family:var(--body-font)!important;border:1px solid var(--santander-grey-300)!important;border-radius:6px!important;
}
input:focus,select:focus,textarea:focus{
  border-color:var(--santander-red)!important;outline:0!important;box-shadow:0 0 0 3px rgba(236,0,0,.12)!important;
}
.badge,.chip,.tag{border-radius:999px!important}
.badge.en-curso,.badge.alta,.badge.critica,.badge.crítica{background:var(--santander-red-soft)!important;color:var(--santander-red-dark)!important}
.notice,.alert,.callout{border-left:6px solid var(--santander-red)!important;background:#fff!important}
pre,code,.code-block{background:#F2F2F2!important;border-color:#D5D5D5!important}
footer{border-top:1px solid var(--santander-grey-200)!important;color:var(--santander-grey-700)!important}
@media print {
  header,aside,.header-actions,.actions,.toolbar,footer{display:none!important}
  body,main{background:#fff!important;color:#111!important}
  main{width:100%!important;max-width:none!important;margin:0!important;padding:0!important}
  h1,h2{color:var(--santander-red-dark)!important}
  table th{background:var(--santander-red-dark)!important;color:#fff!important;-webkit-print-color-adjust:exact;print-color-adjust:exact}
  .notice,.alert,.callout{border-left-color:var(--santander-red)!important;-webkit-print-color-adjust:exact;print-color-adjust:exact}
}
/* V25.2 — Cabecera corporativa: símbolo rojo íntegro sobre fondo blanco */
header{
  min-height:68px!important;
  height:auto!important;
  padding:10px 22px!important;
  background:#FFFFFF!important;
  color:#222222!important;
  border-bottom:4px solid #EC0000!important;
  box-shadow:0 2px 10px rgba(0,0,0,.08)!important;
  overflow:visible!important;
}
.brand{
  min-width:0!important;
  color:#222222!important;
  font-family:var(--brand-font,"Santander Headline","Segoe UI",Arial,sans-serif)!important;
  font-size:20px!important;
  line-height:1.15!important;
  font-weight:600!important;
  display:flex!important;
  align-items:center!important;
  gap:13px!important;
  white-space:nowrap!important;
  overflow:visible!important;
}
.brand::before{
  content:""!important;
  display:block!important;
  width:46px!important;
  height:46px!important;
  min-width:46px!important;
  max-width:46px!important;
  flex:0 0 46px!important;
  background-color:#FFFFFF!important;
  background-repeat:no-repeat!important;
  background-position:center!important;
  background-size:contain!important;
  border:0!important;
  border-radius:0!important;
  box-shadow:none!important;
}
@media(max-width:700px){
  header{min-height:60px!important;padding:8px 14px!important}
  .brand{font-size:17px!important;gap:10px!important}
  .brand::before{width:38px!important;height:38px!important;min-width:38px!important;max-width:38px!important;flex-basis:38px!important}
}

/* V25.3 — Auditoría de legibilidad y contraste */
:root{
  --accessible-text:#202124;
  --accessible-muted:#5F6368;
  --accessible-border:#AEB4BA;
  --accessible-link:#B30000;
  --accessible-focus:#8A0000;
  --code-bg:#1F2328;
  --code-head:#2D333B;
  --code-text:#F0F3F6;
  --code-muted:#B7C0CA;
  --code-keyword:#FF9A91;
  --code-string:#B6D7FF;
  --code-number:#91CBFF;
  --code-comment:#B7C0CA;
  --code-variable:#FFC07A;
  --code-builtin:#DFB6FF;
  --code-pipe:#FFD866;
}
body{color:var(--accessible-text)!important}
a{color:var(--accessible-link)!important}
a:hover,a:focus{text-decoration:underline!important;color:#8A0000!important}
small,.muted,.meta,.aside-note,.page-head p,.stats span,.stat span,.card-meta{
  color:var(--accessible-muted)!important;
  opacity:1!important;
}
button:focus-visible,a:focus-visible,input:focus-visible,select:focus-visible,textarea:focus-visible{
  outline:3px solid var(--accessible-focus)!important;
  outline-offset:2px!important;
}
input,select,textarea{
  color:#202124!important;
  background:#FFFFFF!important;
  border-color:#8A9097!important;
  opacity:1!important;
}
input::placeholder,textarea::placeholder{color:#656B72!important;opacity:1!important}
button:disabled,.btn:disabled{opacity:.65!important;color:#3C4043!important}

/* Código: contraste alto y sin transparencias */
.code-wrap,.code-block,.code-container,.editor-code{
  background:var(--code-bg)!important;
  border-color:#59636E!important;
  opacity:1!important;
}
.code-head,.code-header,.code-title{
  background:var(--code-head)!important;
  color:#FFFFFF!important;
  border-color:#59636E!important;
  opacity:1!important;
}
.code-box,.code-box code,pre,pre code,.content pre,.content pre code{
  background:var(--code-bg)!important;
  color:var(--code-text)!important;
  font-family:Consolas,"Courier New",monospace!important;
  font-size:14px!important;
  line-height:1.65!important;
  opacity:1!important;
  text-shadow:none!important;
  filter:none!important;
}
.code-box *,pre *,pre code *{
  opacity:1!important;
  text-shadow:none!important;
  filter:none!important;
}
.tok-keyword{color:var(--code-keyword)!important;font-weight:700!important}
.tok-string{color:var(--code-string)!important}
.tok-comment{color:var(--code-comment)!important;font-style:italic!important}
.tok-number{color:var(--code-number)!important}
.tok-builtin{color:var(--code-builtin)!important}
.tok-variable{color:var(--code-variable)!important}
.tok-operator{color:#FF9A91!important;font-weight:700!important}
.tok-pipe{color:var(--code-pipe)!important;font-weight:800!important}
.tok-key,.tok-tag{color:#9BE9A8!important}
.copy-code,.code-head button,.code-header button{
  background:#FFFFFF!important;
  color:#8A0000!important;
  border:1px solid #FFFFFF!important;
  font-weight:700!important;
}

/* Avisos: texto oscuro y fondos claros */
.admonition,.notice,.alert{
  color:#202124!important;
  opacity:1!important;
}
.admonition *,.notice *,.alert *{opacity:1!important}
.admonition.advertencia,.warning{
  background:#FFF4E5!important;
  border-color:#C54800!important;
  color:#3B2500!important;
}
.admonition.informacion,.admonition.nota,.info{
  background:#F3F6F9!important;
  border-color:#B30000!important;
  color:#202124!important;
}
.admonition.importante{
  background:#FDECEC!important;
  border-color:#B30000!important;
  color:#4A0000!important;
}
.admonition.error,.error{
  background:#FCE8E6!important;
  border-color:#A50E0E!important;
  color:#5F0000!important;
}

/* Tablas, tarjetas, etiquetas y estados */
th{background:#ECEFF1!important;color:#30343B!important}
td{color:#202124!important}
.card,section,.stat,.project-card,.info-card{
  color:#202124!important;
}
.badge,.tag{
  color:#30343B!important;
  opacity:1!important;
}
.status-en-curso,.badge.en-curso{background:#FFE1E1!important;color:#8A0000!important}
.status-finalizado,.status-completada,.badge.resuelta,.badge.cerrada{
  background:#DFF1E5!important;color:#1F5D36!important;
}
.status-bloqueada,.status-cancelado,.priority-critica,.badge.priority.critica{
  background:#F8D7DA!important;color:#721C24!important;
}
.primary,.btn.primary{
  background:#EC0000!important;color:#FFFFFF!important;border-color:#B30000!important;
}
.primary:hover,.btn.primary:hover{background:#B30000!important;color:#FFFFFF!important}

/* V25.4 — Selecciones legibles y zona de información ampliada */
html,body{width:100%;min-width:0}
.shell{
  width:calc(100% - 24px)!important;
  max-width:1920px!important;
  margin:0 auto!important;
  grid-template-columns:230px minmax(0,1fr)!important;
}
main{
  width:100%!important;
  max-width:none!important;
  min-width:0!important;
  margin:0!important;
  padding:20px 24px 36px!important;
}
main > *,article,.content,.page-content,.dashboard-grid{
  max-width:none!important;
}
article{width:100%!important}
.card,section,.hero,.panel{
  max-width:none!important;
}
.form-card,.editor,.github-editor,.info-card{
  max-width:none!important;
  width:100%!important;
}
.table-wrap,.pending-card,.pending-table{
  width:100%!important;
  max-width:none!important;
}
table{width:100%!important}

/* Filtros y pestañas: estados claramente visibles */
.pending-filters,.search-filters,.module-tabs{
  display:flex!important;
  flex-wrap:wrap!important;
  gap:8px!important;
  align-items:center!important;
}
.pending-filter,.search-filters a,.module-tabs a{
  display:inline-flex!important;
  align-items:center!important;
  justify-content:center!important;
  min-height:36px!important;
  padding:8px 14px!important;
  border:1px solid #B8BEC5!important;
  border-radius:999px!important;
  background:#FFFFFF!important;
  color:#9B0000!important;
  font-size:13px!important;
  line-height:1.2!important;
  font-weight:600!important;
  text-decoration:none!important;
  opacity:1!important;
  white-space:nowrap!important;
}
.pending-filter:hover,.search-filters a:hover,.module-tabs a:hover{
  background:#FDECEC!important;
  border-color:#EC0000!important;
  color:#780000!important;
  text-decoration:none!important;
}
.pending-filter.active,.search-filters a.active,.module-tabs a.active{
  background:#EC0000!important;
  border-color:#B30000!important;
  color:#FFFFFF!important;
  font-weight:700!important;
  box-shadow:0 0 0 1px #EC0000!important;
}
.pending-filter.active *,
.search-filters a.active *,
.module-tabs a.active *{
  color:#FFFFFF!important;
}

/* Tarjetas resumen */
.pending-summary{
  grid-template-columns:repeat(4,minmax(180px,1fr))!important;
  gap:12px!important;
}
.pending-chip{
  min-height:72px!important;
  padding:14px 16px!important;
  background:#FFFFFF!important;
  color:#30343B!important;
  border:1px solid #C7CDD3!important;
}
.pending-chip:hover{
  background:#FFF5F5!important;
  border-color:#EC0000!important;
  text-decoration:none!important;
}
.pending-chip strong{font-size:24px!important;color:#202124!important}

/* Ventanas y cuadros de información más amplios */
.import-dialog,.modal-dialog,.dialog,.popup,.detail-dialog{
  width:min(1100px,calc(100vw - 40px))!important;
  max-width:1100px!important;
  max-height:92vh!important;
}
.import-dialog-body,.modal-body,.dialog-body{
  padding:22px 24px!important;
}
.project-grid{
  grid-template-columns:repeat(auto-fit,minmax(280px,1fr))!important;
}
.detail-grid{
  grid-template-columns:repeat(2,minmax(0,1fr))!important;
}
.editor-row{
  grid-template-columns:repeat(2,minmax(0,1fr))!important;
}

@media(min-width:1600px){
  .shell{width:calc(100% - 32px)!important;max-width:2200px!important}
  main{padding:22px 30px 42px!important}
}
@media(max-width:1050px){
  .pending-summary{grid-template-columns:repeat(2,minmax(160px,1fr))!important}
  .detail-grid,.editor-row{grid-template-columns:1fr!important}
}
@media(max-width:850px){
  .shell{display:block!important;width:100%!important}
  main{padding:16px!important}
  .pending-summary{grid-template-columns:1fr!important}
  .pending-filter,.search-filters a,.module-tabs a{font-size:12px!important;padding:8px 12px!important}
}

/* V25.5 — Tipografía exacta para PDF */
@media print {
  html,body,main,article,.content,.page-content{
    font-size:12px!important;
    line-height:1.45!important;
  }

  p,li,dd,dt,td,th,span,div,label{
    font-size:12px!important;
  }

  h1,h2,h3,h4,h5,h6,
  .page-title,.section-title,.card-title{
    font-size:14px!important;
    line-height:1.25!important;
  }

  .email-example,
  .email-example *,
  .communication-email,
  .communication-email *,
  .communication-case,
  .communication-case *,
  .communication-response,
  .communication-response *,
  .case-field,
  .case-field *,
  .admonition,
  .admonition *,
  .notice,
  .notice *,
  .alert,
  .alert *,
  .callout,
  .callout *,
  .code-wrap,
  .code-wrap *,
  .code-box,
  .code-box *,
  .code-head,
  .code-head *,
  pre,
  pre *,
  code,
  code *{
    font-size:9px!important;
    line-height:1.4!important;
  }

  .email-example-title,
  .communication-title,
  .admonition-title,
  .code-head{
    font-size:9px!important;
    font-weight:700!important;
  }

  .email-example,
  .communication-email,
  .communication-case,
  .communication-response,
  .admonition,
  .notice,
  .alert,
  .callout,
  .code-wrap,
  pre{
    break-inside:avoid!important;
    page-break-inside:avoid!important;
  }
}
"""

BASE=Path(__file__).resolve().parent
RESPONSIBLES_DB=BASE.parent/'gestor'/'data'/'responsibles.json'
DATA=BASE/'data'; DB=DATA/'entries.json'; GROUPS_DB=DATA/'groups.json'; LEGACY_UPLOADS=DATA/'uploads'; UPLOADS=BASE.parent.parent/'imagenes'
DATA.mkdir(exist_ok=True); LEGACY_UPLOADS.mkdir(parents=True,exist_ok=True); UPLOADS.mkdir(parents=True,exist_ok=True)
for old_image in LEGACY_UPLOADS.iterdir():
    if old_image.is_file() and not (UPLOADS/old_image.name).exists():
        try:
            import shutil; shutil.copy2(old_image,UPLOADS/old_image.name)
        except OSError: pass
PORTAL_URL=os.environ.get('PORTAL_URL','http://127.0.0.1:8079')
WIKI_URL=os.environ.get('WIKI_URL','http://127.0.0.1:8080')
GESTOR_URL=os.environ.get('GESTOR_URL','http://127.0.0.1:8081')
BAU_URL=os.environ.get('BAU_URL','http://127.0.0.1:8082')
BIBLIOTECA_URL=os.environ.get('BIBLIOTECA_URL','http://127.0.0.1:8084')
CAMBIOS_URL=os.environ.get('CAMBIOS_URL','http://127.0.0.1:8085')
DEFAULT_GROUPS=['Correo','Novedades','FollowTheSun','Acta','CEA','Peticiones','Migracion']


def esc(v): return html.escape(str(v or ''),quote=True)
def load():
    try:return json.loads(DB.read_text(encoding='utf-8')) if DB.exists() else []
    except Exception:return []
def save(rows): DB.write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8')
def load_groups():
    try:
        values=json.loads(GROUPS_DB.read_text(encoding='utf-8')) if GROUPS_DB.exists() else DEFAULT_GROUPS
    except Exception:
        values=DEFAULT_GROUPS
    clean=[]
    for value in values:
        name=str(value or '').strip()
        if name and name.casefold() not in {x.casefold() for x in clean}: clean.append(name)
    if not clean: clean=list(DEFAULT_GROUPS)
    if not GROUPS_DB.exists(): save_groups(clean)
    return clean
def save_groups(values):
    clean=[]
    for value in values:
        name=str(value or '').strip()
        if name and name.casefold() not in {x.casefold() for x in clean}: clean.append(name)
    GROUPS_DB.write_text(json.dumps(clean or list(DEFAULT_GROUPS),ensure_ascii=False,indent=2),encoding='utf-8')
def now(): return datetime.now().isoformat(timespec='seconds')
def getone(rid): return next((x for x in load() if x.get('id')==rid),None)
def options(values,current=''): return ''.join(f'<option value="{esc(x)}" {"selected" if x==current else ""}>{esc(x)}</option>' for x in values)

def responsible_people():
    try:
        rows=json.loads(RESPONSIBLES_DB.read_text(encoding='utf-8')) if RESPONSIBLES_DB.exists() else []
    except Exception:
        rows=[]
    return sorted(rows,key=lambda x:(0 if str(x.get('name','')).strip().casefold() in ('emailsecurity','mailsecurity') else 1,str(x.get('name','')).strip().casefold()))

def selected_responsible_ids(item):
    values=item.get('responsible_ids',[])
    if isinstance(values,str):
        values=[x.strip() for x in values.split(',') if x.strip()]
    if not values and item.get('responsible_id'):
        values=[str(item.get('responsible_id'))]
    return [str(x) for x in values if str(x).strip()]

def responsible_names(ids):
    chosen={str(x) for x in ids}
    return [str(person.get('name','')).strip() for person in responsible_people() if str(person.get('id')) in chosen and str(person.get('name','')).strip()]

def responsible_multiselect(item=None):
    item=item or {}
    selected=selected_responsible_ids(item)
    chosen=set(selected)
    people=responsible_people()
    names=responsible_names(selected)
    summary=', '.join(names) if names else 'Seleccionar responsables'
    checks=''.join(
        '<label class="responsible-menu-check"><input type="checkbox" class="responsible-menu-checkbox" name="responsible_ids" value="'
        +esc(person.get('id'))+'" data-responsible-name="'+esc(person.get('name'))+'" '
        +('checked' if str(person.get('id')) in chosen else '')
        +'><span>'+esc(person.get('name'))+'</span></label>'
        for person in people
    ) or '<div class="responsible-empty">No hay responsables creados.</div>'
    return (
        '<div class="responsible-dropdown-field"><span class="field-label">Responsable o responsables</span>'
        '<details class="responsible-multiselect" data-responsible-menu>'
        '<summary><span data-responsible-summary>'+esc(summary)+'</span><span class="responsible-arrow">▾</span></summary>'
        '<div class="responsible-menu-options">'+checks+'</div></details>'
        '<small>Seleccione uno o varios responsables.</small></div>'
    )

def responsible_name_list(item):
    names=responsible_names(selected_responsible_ids(item))
    return ', '.join(names) if names else 'Sin asignar'

def tags_list(value): return [x.strip() for x in re.split(r'[,;]',value or '') if x.strip()]
def badge(v): return f'<span class="badge">{esc(v)}</span>'

def inline_format(value):
    text=esc(value)
    text=re.sub(r'\*\*(.+?)\*\*',r'<strong>\1</strong>',text,flags=re.S)
    text=re.sub(r"''(.+?)''",r'<em>\1</em>',text,flags=re.S)
    text=re.sub(r'\[u\](.+?)\[/u\]',r'<u>\1</u>',text,flags=re.S|re.I)
    text=re.sub(r'\[azul\](.*?)\[/azul\]',r'<span class="text-blue">\1</span>',text,flags=re.S|re.I)
    text=re.sub(r'\[rojo\](.*?)\[/rojo\]',r'<span class="text-red">\1</span>',text,flags=re.S|re.I)
    text=re.sub(r'\[amarillo\](.*?)\[/amarillo\]',r'<mark>\1</mark>',text,flags=re.S|re.I)
    text=re.sub(r'\[([^\]]+)\]\((https?://[^)]+)\)',r'<a href="\2" target="_blank" rel="noopener">\1</a>',text)
    return text

def preserve_rendered_indent(line):
    expanded=str(line or '').expandtabs(4)
    leading=len(expanded)-len(expanded.lstrip(' '))
    if not leading:
        return line
    return '<span class="text-indent">'+('&#160;'*leading)+'</span>'+expanded.lstrip(' ')

def render(text):
    lines=str(text or '').replace('\r\n','\n').split('\n')
    out=[]; paragraph=[]; list_tag=None; index=0

    def flush_paragraph():
        nonlocal paragraph
        if paragraph:
            out.append('<p>'+'<br>'.join(preserve_rendered_indent(inline_format(line)) for line in paragraph)+'</p>')
            paragraph=[]

    def close_list():
        nonlocal list_tag
        if list_tag:
            out.append(f'</{list_tag}>')
            list_tag=None

    while index < len(lines):
        line=lines[index]
        stripped=line.strip()

        if stripped.startswith('```'):
            flush_paragraph(); close_list()
            language=stripped[3:].strip() or 'text'
            code=[]; index+=1
            while index < len(lines) and lines[index].strip()!='```':
                code.append(lines[index]); index+=1
            if index < len(lines): index+=1
            out.append(
                f'<div class="code-wrap"><div class="code-head"><span>{esc(language)}</span></div>'
                f'<pre class="code-box"><code class="language-{esc(language)}">'
                + html.escape('\n'.join(code))
                + '</code></pre></div>'
            )
            continue

        communication=re.fullmatch(r':::\s*(correo|email|caso|respuesta)(?:\s+(.+))?',stripped,re.I)
        if communication:
            flush_paragraph(); close_list()
            kind=communication.group(1).casefold()
            if kind=='email': kind='correo'
            title=(communication.group(2) or {'correo':'Correo','caso':'Caso','respuesta':'Respuesta'}[kind]).strip()
            block=[]; index+=1
            end_re=re.compile(rf':::\s*end(?:{re.escape(kind)}|correo|email|caso|respuesta)\s*$',re.I)
            while index < len(lines) and not end_re.fullmatch(lines[index].strip()):
                block.append(lines[index]); index+=1
            if index < len(lines): index+=1
            body='<br>'.join(inline_format(x) for x in block)
            out.append(f'<div class="communication {kind}"><div class="communication-title">{esc(title)}</div><div class="communication-body">{body}</div></div>')
            continue

        image=re.fullmatch(r'\[\[imagen:([^|\]]+)(?:\|([^\]]*))?\]\]',stripped)
        if image:
            flush_paragraph(); close_list()
            filename=image.group(1)
            description=image.group(2) or filename
            out.append(f'<img class="embedded-image" src="/uploads/{quote(filename)}" alt="{esc(description)}">')
            index+=1; continue

        heading=re.fullmatch(r'(={2,6})\s*(.*?)\s*\1',stripped)
        if heading:
            flush_paragraph(); close_list()
            level=min(len(heading.group(1)),6)
            out.append(f'<h{level}>{inline_format(heading.group(2))}</h{level}>')
            index+=1; continue

        notice_open=re.match(r'^!!!\s+(nota|advertencia|informacion|información)\s*:?\s*(.*)$',stripped,re.I)
        if notice_open:
            flush_paragraph(); close_list()
            kind=notice_open.group(1).casefold().replace('ó','o')
            trailing=notice_open.group(2).strip()
            block=[]; index+=1
            while index < len(lines) and lines[index].strip()!='!!!':
                block.append(lines[index]); index+=1
            if index < len(lines) and lines[index].strip()=='!!!':
                index+=1
            elif trailing:
                block=[trailing]
            label={'advertencia':'Advertencia','nota':'Nota','informacion':'Información'}[kind]
            content='<br>'.join(inline_format(x) for x in block if x.strip())
            out.append(f'<div class="admonition {kind}"><strong>{label}</strong>{("<div>"+content+"</div>") if content else ""}</div>')
            continue

        bullet=re.match(r'^\s*[-*]\s+(.*)$',line)
        ordered=re.match(r'^\s*\d+\.\s+(.*)$',line)
        if bullet or ordered:
            flush_paragraph()
            wanted='ul' if bullet else 'ol'
            if list_tag != wanted:
                close_list(); out.append(f'<{wanted}>'); list_tag=wanted
            out.append('<li>'+inline_format((bullet or ordered).group(1))+'</li>')
            index+=1; continue

        if not stripped:
            flush_paragraph(); close_list(); index+=1; continue

        close_list(); paragraph.append(line); index+=1

    flush_paragraph(); close_list()
    return ''.join(out)

def layout(title,body):
    links=[('Inicio',PORTAL_URL),('Wiki',WIKI_URL),('Proyectos y tareas',GESTOR_URL),('BAU',BAU_URL),('Bitácora','/'),('Biblioteca',BIBLIOTECA_URL),('Plantillas',CAMBIOS_URL)]
    nav=''.join(f'<a class="{"active" if n=="Bitácora" else ""}" href="{esc(u)}">{esc(n)}</a>' for n,u in links)
    return f'''<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{esc(title)} · Bitácora</title><style>{CSS}
/* V20.1 · Ajuste visual seguro en cajas de edición */
textarea{{white-space:pre-wrap!important;overflow-wrap:anywhere;word-break:normal;overflow-x:hidden}}
.form textarea.code{{white-space:pre-wrap!important;overflow-wrap:anywhere;word-break:normal;overflow-x:hidden}}
</style><style>{CORPORATE_THEME_CSS}
/* V26.1: logotipo configurable desde configuracion/logo/logo.png */
.brand::before{{display:none!important;content:none!important;background-image:none!important}}
.brand .brand-logo{{
  display:block!important;width:46px!important;height:46px!important;
  min-width:46px!important;max-width:46px!important;flex:0 0 46px!important;
  object-fit:contain!important;object-position:center!important;
  background:transparent!important;border:0!important;border-radius:0!important;
  box-shadow:none!important
}}
.brand>span{{display:block!important}}
@media(max-width:760px){{
  .brand .brand-logo{{width:38px!important;height:38px!important;min-width:38px!important;max-width:38px!important;flex-basis:38px!important}}
}}
</style>
<style>
/* V27.3 · Logotipo adaptable al espacio disponible */
header{{
  min-height:72px!important;
  height:auto!important;
  overflow:visible!important;
}}
.brand{{
  min-height:56px!important;
  max-width:min(70vw,760px)!important;
  display:flex!important;
  align-items:center!important;
  gap:14px!important;
  overflow:visible!important;
}}
.brand::before{{
  display:none!important;
  content:none!important;
  background-image:none!important;
}}
.brand .brand-logo{{
  display:block!important;
  width:auto!important;
  height:auto!important;
  min-width:0!important;
  min-height:0!important;
  max-width:210px!important;
  max-height:56px!important;
  flex:0 1 auto!important;
  object-fit:contain!important;
  object-position:left center!important;
  background:transparent!important;
  border:0!important;
  border-radius:0!important;
  box-shadow:none!important;
}}
.brand>span{{
  display:block!important;
  min-width:0!important;
  overflow:hidden!important;
  text-overflow:ellipsis!important;
}}
@media(max-width:760px){{
  header{{min-height:64px!important;padding:8px 14px!important}}
  .brand{{min-height:46px!important;gap:10px!important;max-width:76vw!important}}
  .brand .brand-logo{{
    width:auto!important;
    height:auto!important;
    max-width:145px!important;
    max-height:46px!important;
  }}
}}
@media(max-width:480px){{
  .brand .brand-logo{{max-width:105px!important;max-height:42px!important}}
  .brand>span{{font-size:15px!important}}
}}
</style>

<style>
/* V27.7 · Logotipo ajustado al encabezado */
header{{min-height:58px!important;height:auto!important;padding:6px 16px!important;overflow:hidden!important}}
.brand{{min-height:44px!important;display:flex!important;align-items:center!important;gap:10px!important;max-width:min(64vw,700px)!important;overflow:hidden!important}}
.brand::before{{display:none!important;content:none!important}}
.brand .brand-logo{{display:block!important;width:auto!important;height:auto!important;max-width:150px!important;max-height:40px!important;min-width:0!important;min-height:0!important;flex:0 1 auto!important;object-fit:contain!important;object-position:left center!important}}
.brand>span{{min-width:0!important;overflow:hidden!important;text-overflow:ellipsis!important;white-space:nowrap!important}}
@media(max-width:760px){{.brand .brand-logo{{max-width:110px!important;max-height:36px!important}}.brand>span{{font-size:15px!important}}}}
</style>

<style>
/* V27.9 · Editor de Bitácora agrupado como Wiki */
.wiki-style-toolbar{{display:flex!important;flex-wrap:wrap;gap:7px!important;align-items:center!important;padding:8px!important;background:#f7f7f7!important;border:1px solid #d8d8d8!important;border-radius:7px!important}}
.toolbar-main,.toolbar-groups{{display:flex;flex-wrap:wrap;gap:6px;align-items:center}}
.toolbar-groups{{border-left:1px solid #ccc;padding-left:7px}}
.toolbar-menu{{position:relative}}
.toolbar-menu summary{{list-style:none;cursor:pointer;border:1px solid #b8b8b8;background:#fff;border-radius:5px;padding:7px 10px;font-weight:600}}
.toolbar-menu summary::-webkit-details-marker{{display:none}}
.toolbar-menu-panel{{position:absolute;z-index:50;top:calc(100% + 4px);left:0;min-width:165px;background:#fff;border:1px solid #bbb;border-radius:7px;padding:6px;box-shadow:0 5px 18px rgba(0,0,0,.15);display:grid;gap:4px}}
.toolbar-menu-panel button{{width:100%;text-align:left}}
.communication{{margin:12px 0;border:1px solid #d5d5d5;border-left:5px solid #ec0000;border-radius:7px;background:#fff}}
.communication-title{{font-weight:700;background:#f5f5f5;padding:9px 12px;border-bottom:1px solid #ddd}}
.communication-body{{padding:12px;line-height:1.55}}
.communication.respuesta{{border-left-color:#007a3d}}
.communication.respuesta .communication-title{{background:#eaf6ef;color:#174d2e}}
.admonition{{margin:12px 0;padding:12px;border-left:5px solid #b30000;border-radius:6px}}
.admonition>div{{margin-top:6px}}
.admonition.advertencia{{background:#fff4e5;border-color:#c54800}}
.admonition.nota{{background:#f3f6f9;border-color:#b30000}}
.admonition.informacion{{background:#eaf3ff;border-color:#2563a7}}
.code-wrap{{margin:12px 0;border:1px solid #59636e;border-radius:7px;overflow:hidden}}
.code-head{{padding:7px 10px;background:#2d333b;color:#fff;font-weight:700}}
.code-box{{margin:0!important;border:0!important;border-radius:0!important}}
@media(max-width:800px){{.toolbar-groups{{border-left:0;padding-left:0}}.toolbar-menu-panel{{position:fixed;left:10%;right:10%;top:auto;min-width:0}}
</style>

<style>
/* V27.11.3 · Selector múltiple de responsables en Bitácora */
.bitacora-top-row{{
  display:grid!important;
  grid-template-columns:minmax(180px,.55fr) minmax(420px,1.65fr) minmax(230px,.75fr)!important;
  gap:12px!important;
  align-items:start!important;
  margin-bottom:12px!important;
}}
.bitacora-second-row{{
  display:grid!important;
  grid-template-columns:minmax(420px,1.45fr) minmax(320px,1fr)!important;
  gap:12px!important;
  align-items:start!important;
  margin-bottom:14px!important;
}}
.bitacora-top-row label,.bitacora-second-row label{{margin:0!important}}
.responsible-dropdown-field{{min-width:0}}
.responsible-dropdown-field>.field-label{{display:block;font-weight:600;margin-bottom:5px}}
.responsible-multiselect{{position:relative;width:100%}}
.responsible-multiselect summary{{
  min-height:38px;display:flex;align-items:center;justify-content:space-between;
  gap:10px;padding:8px 11px;border:1px solid #8a9097;border-radius:6px;
  background:#fff;cursor:pointer;list-style:none;
}}
.responsible-multiselect summary::-webkit-details-marker{{display:none}}
.responsible-multiselect [data-responsible-summary]{{
  display:block;min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;
}}
.responsible-arrow{{flex:0 0 auto}}
.responsible-menu-options{{
  position:absolute;z-index:160;top:calc(100% + 4px);left:0;right:0;
  max-height:260px;overflow:auto;padding:7px;background:#fff;
  border:1px solid #b8bec5;border-radius:7px;box-shadow:0 8px 24px rgba(0,0,0,.16);
}}
.responsible-menu-check{{
  display:flex!important;align-items:center!important;gap:8px!important;
  padding:7px 8px!important;margin:0!important;border-radius:5px;cursor:pointer;
}}
.responsible-menu-check:hover{{background:#fdecec}}
.responsible-menu-check input{{
  width:16px!important;height:16px!important;flex:0 0 16px!important;margin:0!important;
}}
.responsible-menu-check span{{display:inline!important;line-height:1.2}}
.responsible-dropdown-field small{{display:block;margin-top:4px;color:#666}}
@media(max-width:950px){{
  .bitacora-top-row,.bitacora-second-row{{grid-template-columns:1fr!important}}
  .responsible-menu-options{{position:static;margin-top:5px}}
}}
</style>

<style>
/* V27.11.4 · Edición de comentarios */
.comment-actions{{display:flex;align-items:center;gap:12px}}
.comment-actions form{{margin:0}}
.comment-edit,.comment-delete{{
  border:0;background:transparent!important;padding:0!important;
  font:inherit;color:#8a0000!important;text-decoration:none;cursor:pointer;
}}
.comment-edit:hover,.comment-delete:hover{{text-decoration:underline}}
.comment-edit-form label{{display:block;font-weight:600}}
.comment-edit-form textarea{{width:100%;margin-top:7px}}
</style>
</head><body><header><div class="brand"><img class="brand-logo" src="/logo.png?v=27112" alt="Logo Santander" onerror="this.style.display=\'none\'"><span>Santander Mail Security · Bitácora</span></div><div class="header-actions"><a class="btn" href="/">← Atrás</a><a class="btn" href="{esc(PORTAL_URL)}">Inicio común</a><a class="btn primary" href="/new">+ Nueva entrada</a></div></header><div class="shell"><aside><nav>{nav}</nav><div class="aside-note">Aplicación local<br>Sin usuarios<br>Datos en JSON</div></aside><main>{body}</main></div><script src="/editor.js"></script>
<script>
document.addEventListener('DOMContentLoaded',function(){{
  document.querySelectorAll('[data-responsible-menu]').forEach(function(menu){{
    const summary=menu.querySelector('[data-responsible-summary]');
    const checks=Array.from(menu.querySelectorAll('.responsible-menu-checkbox'));
    function update(){{
      const names=checks.filter(x=>x.checked).map(x=>x.dataset.responsibleName||'').filter(Boolean);
      if(summary)summary.textContent=names.length?names.join(', '):'Seleccionar responsables';
    }}
    checks.forEach(x=>x.addEventListener('change',update));
    update();
  }});
  document.addEventListener('click',function(event){{
    document.querySelectorAll('[data-responsible-menu][open]').forEach(function(menu){{
      if(!menu.contains(event.target))menu.open=false;
    }});
  }});
}});
</script>
</body></html>'''

def dashboard(qs):
    rows=load(); groups=load_groups(); term=qs.get('q',[''])[0].strip().casefold(); group=qs.get('group',[''])[0]; day=qs.get('date',[''])[0]
    filtered=[]
    for r in rows:
        hay=' '.join([r.get('title',''),r.get('group',''),r.get('content',''),r.get('tags',''),r.get('wiki_link',''),r.get('bau_link','')]).casefold()
        if (not term or term in hay) and (not group or r.get('group')==group) and (not day or r.get('date')==day): filtered.append(r)
    filtered.sort(key=lambda x:(x.get('date',''),x.get('updated','')),reverse=True)
    group_counts=''.join(f'<a class="group-card {"selected" if group==g else ""}" href="/?group={quote(g)}"><strong>{sum(1 for r in rows if r.get("group")==g)}</strong><span>{esc(g)}</span></a>' for g in groups)
    trs=''.join(f'''<tr><td>{esc(r.get('date'))}</td><td>{badge(r.get('group'))}</td><td class="entry-title"><a href="/view?id={esc(r.get('id'))}"><strong>{esc(r.get('title'))}</strong></a><small>{' '.join('#'+esc(t) for t in tags_list(r.get('tags','')))}</small></td><td>{esc(r.get('updated','')[:16].replace('T',' '))}</td></tr>''' for r in filtered) or '<tr><td colspan="4" class="empty">No hay entradas de bitácora.</td></tr>'
    body=f'''<div class="page-head"><div><h1>Cuaderno de Bitácora</h1><p>Novedades, cambios, investigaciones y apuntes técnicos ordenados por fecha y grupo.</p></div><div><a class="btn" href="/groups">Gestionar grupos</a></div></div><div class="groups"><a class="group-card {"selected" if not group else ""}" href="/"><strong>{len(rows)}</strong><span>Todos</span></a>{group_counts}</div><section class="card"><form class="filters" method="get"><input name="q" value="{esc(qs.get('q',[''])[0])}" placeholder="Buscar en título, contenido, etiquetas o enlaces"><select name="group"><option value="">Todos los grupos</option>{options(groups,group)}</select><input type="date" name="date" value="{esc(day)}"><button class="btn primary">Filtrar</button><a class="btn ghost" href="/">Limpiar</a></form></section><section class="card"><div class="section-head"><h2>Entradas</h2><a class="btn primary" href="/new">+ Nueva entrada</a></div><div class="table-wrap"><table><thead><tr><th>Fecha</th><th>Grupo</th><th>Título y etiquetas</th><th>Actualizada</th></tr></thead><tbody>{trs}</tbody></table></div></section>'''
    return layout('Cuaderno de Bitácora',body)

def editor_field(value):
    return f'''<section class="editor-block">
    <div class="editor-head"><h2>Contenido</h2></div>
    <div class="toolbar wiki-style-toolbar" data-target="content">
      <div class="toolbar-main">
        <button type="button" data-heading="2">Título</button>
        <button type="button" data-wrap="**">Negrita</button>
        <button type="button" data-wrap="''">Cursiva</button>
        <button type="button" data-wrap-open="[u]" data-wrap-close="[/u]">Subrayado</button>
        <button type="button" data-wrap-open="[azul]" data-wrap-close="[/azul]">Azul</button>
        <button type="button" data-wrap-open="[rojo]" data-wrap-close="[/rojo]">Rojo</button>
        <button type="button" data-wrap-open="[amarillo]" data-wrap-close="[/amarillo]">Resaltar</button>
        <button type="button" data-insert="- ">Lista</button>
        <button type="button" data-indent="1">→ Tab +4</button>
        <button type="button" data-outdent="1">← Quitar tab</button>
      </div>
      <div class="toolbar-groups">
        <details class="toolbar-menu">
          <summary>✉ Comunicación</summary>
          <div class="toolbar-menu-panel">
            <button type="button" data-communication="correo">Correo</button>
            <button type="button" data-communication="caso">Caso</button>
            <button type="button" data-communication="respuesta">Respuesta</button>
          </div>
        </details>
        <details class="toolbar-menu">
          <summary>⚠ Avisos</summary>
          <div class="toolbar-menu-panel">
            <button type="button" data-notice="nota">Nota</button>
            <button type="button" data-notice="advertencia">Advertencia</button>
            <button type="button" data-notice="informacion">Información</button>
          </div>
        </details>
        <details class="toolbar-menu">
          <summary>⌨ Código</summary>
          <div class="toolbar-menu-panel">
            <button type="button" data-code="spl">SPL</button>
            <button type="button" data-code="python">Python</button>
            <button type="button" data-code="text">Texto</button>
          </div>
        </details>
        <button type="button" data-image="1">🖼 Imagen</button>
      </div>
    </div>
    <textarea wrap="soft" id="content" name="content" rows="18" required>{esc(value)}</textarea>
    <input class="bau-image-input" data-editor="content" type="file" accept="image/*" hidden>
    <span class="upload-status" data-status="content"></span>
    </section>'''

def form_page(r=None):
    r=r or {}; editing=bool(r); groups=load_groups()
    body=f'''<div class="page-head"><div><h1>{'Editar' if editing else 'Nueva'} entrada</h1><p>Registra la novedad con fecha, grupo y etiquetas para localizarla fácilmente.</p></div></div>
    <form class="card form" method="post" action="/save">
      <input type="hidden" name="id" value="{esc(r.get('id'))}">
      <div class="bitacora-top-row">
        <label>Fecha<input type="date" name="date" value="{esc(r.get('date') or datetime.now().date())}" required></label>
        <label>Título<input name="title" value="{esc(r.get('title'))}" maxlength="180" required placeholder="Resumen breve de la novedad"></label>
        <label>Grupo<select name="group" required>{options(groups,r.get('group',groups[0] if groups else 'Correo'))}</select></label>
      </div>
      <div class="bitacora-second-row">
        {responsible_multiselect(r)}
        <label>Etiquetas<input name="tags" value="{esc(r.get('tags'))}" placeholder="Ej.: colas, configuración, incidencia"></label>
      </div>
      {editor_field(r.get('content',''))}
      <div class="grid links">
        <label>Wiki relacionada (slug o enlace)<input name="wiki_link" value="{esc(r.get('wiki_link'))}" placeholder="RFC, slug o URL"></label>
        <label>BAU relacionada (ID o enlace)<input name="bau_link" value="{esc(r.get('bau_link'))}" placeholder="INC..., RITM... o URL"></label>
        <label class="wide">Enlace externo adicional<input name="external_link" value="{esc(r.get('external_link'))}" placeholder="https://..."></label>
      </div>
      <div class="actions"><button class="btn primary">Guardar entrada</button><a class="btn ghost" href="/">Cancelar</a></div>
    </form>'''
    return layout('Editor de Bitácora',body)

def groups_page(message=''):
    groups=load_groups(); rows=load()
    notice=f'<div class="notice">{esc(message)}</div>' if message else ''
    items=''
    for index,name in enumerate(groups):
        used=sum(1 for row in rows if row.get('group')==name)
        items+=f'''<tr><td>{index+1}</td><td><form class="group-edit-form" method="post" action="/groups/rename"><input type="hidden" name="old" value="{esc(name)}"><input name="new" value="{esc(name)}" maxlength="80" required><button class="btn">Guardar nombre</button></form></td><td>{used}</td><td><form method="post" action="/groups/delete" onsubmit="return confirm('¿Eliminar este grupo?')"><input type="hidden" name="name" value="{esc(name)}"><button class="btn danger" {'disabled title="No puede eliminarse mientras tenga entradas"' if used else ''}>Eliminar</button></form></td></tr>'''
    body=f'''<div class="page-head"><div><h1>Grupos de Bitácora</h1><p>Crea, modifica y elimina los grupos disponibles en las entradas.</p></div><div><a class="btn" href="/">Volver a la Bitácora</a></div></div>{notice}<section class="card"><h2>Añadir grupo</h2><form class="group-add-form" method="post" action="/groups/add"><input name="name" maxlength="80" required placeholder="Nombre del nuevo grupo"><button class="btn primary">Añadir grupo</button></form></section><section class="card"><h2>Grupos configurados</h2><div class="table-wrap"><table><thead><tr><th>Orden</th><th>Nombre</th><th>Entradas</th><th>Acción</th></tr></thead><tbody>{items}</tbody></table></div><p><small>Un grupo con entradas no puede eliminarse hasta que sus entradas se muevan o se renombre el grupo.</small></p></section>'''
    return layout('Grupos de Bitácora',body)

def smart_link(value,base):
    if not value:return '—'
    href=value if re.match(r'^https?://',value,re.I) else base.rstrip('/')+'/'+quote(value.strip('/'))
    return f'<a href="{esc(href)}" target="_blank">{esc(value)}</a>'
def view_page(r):
    tag_html=''.join(f'<span class="tag">#{esc(t)}</span>' for t in tags_list(r.get('tags','')))
    comments=sorted(r.get('comments',[]) if isinstance(r.get('comments',[]),list) else [],key=lambda x:x.get('created',''))
    comment_items=''
    for comment in comments:
        comment_items+=f'''<article class="comment-item"><div class="comment-meta"><strong>{esc(comment.get('created','').replace('T',' '))}</strong><div class="comment-actions"><a class="comment-edit" href="/comment/edit?entry_id={esc(r['id'])}&comment_id={esc(comment.get('id'))}">Editar</a><form method="post" action="/comment/delete" onsubmit="return confirm('¿Eliminar este comentario?')"><input type="hidden" name="entry_id" value="{esc(r['id'])}"><input type="hidden" name="comment_id" value="{esc(comment.get('id'))}"><button class="comment-delete" type="submit">Eliminar</button></form></div></div><div class="comment-text">{render(comment.get('text',''))}</div></article>'''
    if not comment_items:
        comment_items='<p class="comments-empty">Todavía no hay comentarios.</p>'
    body=f'''<div class="page-head"><div><div class="eyebrow">{esc(r.get('date'))} · {esc(r.get('group'))}</div><h1>{esc(r.get('title'))}</h1><div class="tag-row">{tag_html}</div></div><div><a class="btn" href="/edit?id={esc(r['id'])}">Editar</a> <form class="inline" method="post" action="/delete" onsubmit="return confirm('¿Eliminar esta entrada de bitácora?')"><input type="hidden" name="id" value="{esc(r['id'])}"><button class="btn danger">Eliminar</button></form></div></div><section class="card content">{render(r.get('content',''))}</section><section class="card"><h2>Relaciones y enlaces</h2><div class="meta-grid"><div><strong>Wiki relacionada</strong><span>{smart_link(r.get('wiki_link'),WIKI_URL+'/wiki')}</span></div><div><strong>BAU relacionada</strong><span>{smart_link(r.get('bau_link'),BAU_URL+'/view?id=')}</span></div><div><strong>Enlace externo</strong><span>{smart_link(r.get('external_link'),'')}</span></div><div><strong>Responsables</strong><span>{esc(responsible_name_list(r))}</span></div><div><strong>Última actualización</strong><span>{esc(r.get('updated','').replace('T',' '))}</span></div></div></section><section class="card comments-card"><div class="section-head"><h2>Comentarios</h2><span class="comment-count">{len(comments)}</span></div><div class="comments-list">{comment_items}</div><form class="comment-form" method="post" action="/comment/add"><input type="hidden" name="entry_id" value="{esc(r['id'])}"><label>Nuevo comentario<textarea wrap="soft" name="text" rows="4" maxlength="4000" required placeholder="Escriba el seguimiento o actualización..."></textarea></label><div class="actions"><button class="btn primary" type="submit">Añadir comentario</button></div></form></section>'''
    return layout(r.get('title','Bitácora'),body)



def comment_edit_page(entry_id,comment_id):
    entry=getone(entry_id)
    if not entry:
        return layout('Comentario no encontrado','<h1>Entrada no encontrada</h1>')
    comments=entry.get('comments',[])
    if not isinstance(comments,list):
        comments=[]
    comment=next((x for x in comments if str(x.get('id'))==str(comment_id)),None)
    if not comment:
        return layout('Comentario no encontrado','<h1>Comentario no encontrado</h1>')
    body=f'''<div class="page-head"><div><h1>Editar comentario</h1><p>Modifica el seguimiento sin crear un comentario nuevo.</p></div></div>
    <form class="card comment-edit-form" method="post" action="/comment/save">
      <input type="hidden" name="entry_id" value="{esc(entry_id)}">
      <input type="hidden" name="comment_id" value="{esc(comment_id)}">
      <label>Comentario
        <textarea wrap="soft" name="text" rows="8" maxlength="4000" required>{esc(comment.get('text',''))}</textarea>
      </label>
      <div class="actions">
        <button class="btn primary" type="submit">Guardar cambios</button>
        <a class="btn ghost" href="/view?id={esc(entry_id)}">Cancelar</a>
      </div>
    </form>'''
    return layout('Editar comentario',body)


def corporate_logo_path():
    """Devuelve siempre el logo corporativo de la carpeta raíz del proyecto."""
    source=Path(__file__).resolve()
    try:
        app_root=source.parents[2]
    except IndexError:
        app_root=source.parent
    candidates=[
        app_root/"configuracion"/"logo"/"logo.png",
        source.parent/"logo.png",
    ]
    for candidate in candidates:
        if candidate.is_file():
            return candidate
    return None

def serve_corporate_logo(handler):
    path = corporate_logo_path()
    if path is None:
        handler.send_response(404)
        handler.end_headers()
        return
    data = path.read_bytes()
    handler.send_response(200)
    handler.send_header("Content-Type", "image/png")
    handler.send_header("Content-Length", str(len(data)))
    handler.send_header("Cache-Control", "no-cache, no-store, must-revalidate")
    handler.end_headers()
    handler.wfile.write(data)

class Handler(BaseHTTPRequestHandler):
    def send_html(self,s,status=200,ctype='text/html; charset=utf-8'):
        b=s.encode(); self.send_response(status); self.send_header('Content-Type',ctype); self.send_header('Content-Length',str(len(b))); self.end_headers(); self.wfile.write(b)
    def redirect(self,u): self.send_response(303); self.send_header('Location',u); self.end_headers()
    def read_form(self):
        n=int(self.headers.get('Content-Length','0') or 0); return {k:v[-1] for k,v in parse_qs(self.rfile.read(n).decode('utf-8','replace'),keep_blank_values=True).items()}
    def multipart(self,max_size=15*1024*1024):
        ct=self.headers.get('Content-Type',''); m=re.search(r'boundary="?([^";]+)',ct); n=int(self.headers.get('Content-Length','0') or 0)
        if not m or n<=0 or n>max_size:return {},[]
        raw=self.rfile.read(n); boundary=('--'+m.group(1)).encode(); fields={}; files=[]
        for part in raw.split(boundary):
            if b'\r\n\r\n' not in part: continue
            head,body=part.split(b'\r\n\r\n',1); body=body.rstrip(b'\r\n-'); nm=re.search(br'name="([^"]+)"',head)
            if not nm: continue
            name=nm.group(1).decode('utf-8','replace'); fm=re.search(br'filename="([^"]*)"',head)
            if fm:
                fn=Path(fm.group(1).decode('utf-8','replace')).name
                if fn: files.append((name,fn,body))
            else: fields[name]=body.decode('utf-8','replace')
        return fields,files
    def do_GET(self):
        u=urlparse(self.path); qs=parse_qs(u.query)
        if u.path in {"/logo.png", "/corporate-logo.png"}: return serve_corporate_logo(self)
        if u.path=='/': return self.send_html(dashboard(qs))
        if u.path=='/new': return self.send_html(form_page())
        if u.path=='/groups': return self.send_html(groups_page(qs.get('message',[''])[0]))
        if u.path=='/comment/edit':
            return self.send_html(comment_edit_page(qs.get('entry_id',[''])[0],qs.get('comment_id',[''])[0]))
        if u.path in ('/view','/edit'):
            r=getone(qs.get('id',[''])[0])
            if not r:return self.send_error(404)
            return self.send_html(form_page(r) if u.path=='/edit' else view_page(r))
        if u.path=='/editor.js':
            p=BASE/'editor.js'; b=p.read_bytes(); self.send_response(200); self.send_header('Content-Type','text/javascript; charset=utf-8'); self.send_header('Content-Length',str(len(b))); self.end_headers(); return self.wfile.write(b)
        if u.path.startswith('/uploads/'):
            p=(UPLOADS/Path(u.path).name).resolve()
            if UPLOADS.resolve() not in p.parents or not p.is_file():return self.send_error(404)
            b=p.read_bytes(); self.send_response(200); self.send_header('Content-Type',mimetypes.guess_type(p)[0] or 'application/octet-stream'); self.send_header('Content-Length',str(len(b))); self.end_headers(); return self.wfile.write(b)
        self.send_error(404)
    def do_POST(self):
        u=urlparse(self.path)
        if u.path=='/groups/add':
            f=self.read_form(); name=f.get('name','').strip(); groups=load_groups()
            if not name: return self.redirect('/groups?message='+quote('El nombre no puede estar vacío.'))
            if name.casefold() in {g.casefold() for g in groups}: return self.redirect('/groups?message='+quote('El grupo ya existe.'))
            groups.append(name); save_groups(groups); return self.redirect('/groups?message='+quote('Grupo añadido correctamente.'))
        if u.path=='/groups/rename':
            f=self.read_form(); old=f.get('old','').strip(); new=f.get('new','').strip(); groups=load_groups()
            if old not in groups or not new: return self.redirect('/groups?message='+quote('No se pudo modificar el grupo.'))
            if new.casefold()!=old.casefold() and new.casefold() in {g.casefold() for g in groups}: return self.redirect('/groups?message='+quote('Ya existe otro grupo con ese nombre.'))
            groups=[new if g==old else g for g in groups]; save_groups(groups)
            rows=load()
            for row in rows:
                if row.get('group')==old: row['group']=new
            save(rows); return self.redirect('/groups?message='+quote('Grupo modificado correctamente.'))
        if u.path=='/groups/delete':
            f=self.read_form(); name=f.get('name','').strip(); groups=load_groups(); rows=load()
            if any(row.get('group')==name for row in rows): return self.redirect('/groups?message='+quote('No puede eliminarse un grupo que contiene entradas.'))
            groups=[g for g in groups if g!=name]
            if not groups: return self.redirect('/groups?message='+quote('Debe existir al menos un grupo.'))
            save_groups(groups); return self.redirect('/groups?message='+quote('Grupo eliminado correctamente.'))
        if u.path=='/comment/add':
            f=self.read_form(); entry_id=f.get('entry_id','').strip(); text=f.get('text','').strip(); rows=load()
            if not text: return self.redirect('/view?id='+quote(entry_id))
            for row in rows:
                if row.get('id')==entry_id:
                    comments=row.get('comments',[])
                    if not isinstance(comments,list): comments=[]
                    comments.append({'id':uuid.uuid4().hex,'text':text,'created':now()})
                    row['comments']=comments; row['updated']=now(); break
            save(rows); return self.redirect('/view?id='+quote(entry_id))
        if u.path=='/comment/save':
            f=self.read_form(); entry_id=f.get('entry_id','').strip(); comment_id=f.get('comment_id','').strip(); text=f.get('text','').strip(); rows=load()
            if not text:
                return self.redirect('/comment/edit?entry_id='+quote(entry_id)+'&comment_id='+quote(comment_id))
            for row in rows:
                if row.get('id')==entry_id:
                    comments=row.get('comments',[])
                    if isinstance(comments,list):
                        for comment in comments:
                            if str(comment.get('id'))==comment_id:
                                comment['text']=text
                                comment['updated']=now()
                                break
                    row['updated']=now()
                    break
            save(rows); return self.redirect('/view?id='+quote(entry_id))
        if u.path=='/comment/delete':
            f=self.read_form(); entry_id=f.get('entry_id','').strip(); comment_id=f.get('comment_id','').strip(); rows=load()
            for row in rows:
                if row.get('id')==entry_id:
                    comments=row.get('comments',[])
                    if isinstance(comments,list): row['comments']=[c for c in comments if c.get('id')!=comment_id]
                    row['updated']=now(); break
            save(rows); return self.redirect('/view?id='+quote(entry_id))
        if u.path=='/upload-image':
            _,files=self.multipart()
            if not files:return self.send_html(json.dumps({'ok':False,'error':'No se recibió ninguna imagen.'}),400,'application/json; charset=utf-8')
            _,fn,data=files[0]; ext=Path(fn).suffix.lower()
            if ext not in ('.png','.jpg','.jpeg','.gif','.webp'):return self.send_html(json.dumps({'ok':False,'error':'Formato no permitido.'}),400,'application/json; charset=utf-8')
            stored=f'{uuid.uuid4().hex}{ext}'; (UPLOADS/stored).write_bytes(data)
            return self.send_html(json.dumps({'ok':True,'filename':stored},ensure_ascii=False),200,'application/json; charset=utf-8')
        f=self.read_form()
        if u.path=='/save':
            rows=load(); rid=f.get('id') or uuid.uuid4().hex; old=next((x for x in rows if x.get('id')==rid),{})
            r={**old,**{k:f.get(k,'').strip() for k in ('date','group','title','tags','content','wiki_link','bau_link','external_link')}}
            responsible_values=f.get('responsible_ids',[])
            if isinstance(responsible_values,str):
                responsible_values=[responsible_values] if responsible_values else []
            r['responsible_ids']=[str(x) for x in responsible_values if str(x).strip()]
            r.pop('responsible_id',None)
            r['id']=rid; r['created']=old.get('created') or now(); r['updated']=now()
            rows=[x for x in rows if x.get('id')!=rid]+[r]; save(rows); return self.redirect('/view?id='+rid)
        if u.path=='/delete':
            save([x for x in load() if x.get('id')!=f.get('id','')]); return self.redirect('/')
        self.send_error(404)
    def log_message(self,*args): pass

CSS=r'''*{box-sizing:border-box}body{margin:0;font:14px Arial,sans-serif;color:#26384a;background:#f3f6f9}header{height:62px;background:#25364a;color:#fff;padding:0 24px;display:flex;justify-content:space-between;align-items:center}.brand{font-size:19px;font-weight:bold}.header-actions{display:flex;gap:8px}.shell{display:grid;grid-template-columns:210px minmax(0,1fr);min-height:calc(100vh - 62px)}aside{background:#fff;border-right:1px solid #d9e1e8;padding:20px 14px}nav a{display:block;padding:10px 12px;color:#38516b;text-decoration:none;border-radius:5px;margin-bottom: 5px}nav a.active,nav a:hover{background:#FFF0F0;color:#B30000;font-weight:bold}.aside-note{margin:25px 10px;color:#7b8996;font-size:13px;line-height:1.6}main{padding:24px;max-width:1450px;width:100%;margin:0 auto}.page-head{display:flex;justify-content:space-between;gap:20px;align-items:flex-start;margin-bottom:18px}.page-head h1{margin:0 0 5px;font-size:25px}.page-head p{margin:0;color:#657687}.card{background:#fff;border:1px solid #d7e0e8;border-radius:8px;padding:18px;margin-bottom:16px;box-shadow:0 1px 4px #0000000c}.btn{display:inline-block;border:1px solid #bdcad5;background:#fff;color:#31516e;padding:9px 13px;border-radius:5px;text-decoration:none;cursor:pointer;font:inherit}.btn.primary{background:#EC0000;border-color:#EC0000;color:#fff}.btn.ghost{background:#f5f7f9}.btn.danger{background:#a53b3b;border-color:#a53b3b;color:#fff}.groups{display:flex;gap:10px;overflow:auto;padding-bottom:12px}.group-card{min-width:118px;background:#fff;border:1px solid #d7e0e8;border-radius:7px;padding:12px;text-decoration:none;color:#344c62}.group-card strong{display:block;font-size:22px}.group-card span{font-size:12px;color:#687987}.group-card.selected{border-color:#EC0000;background:#FFF0F0}.filters{display:grid;grid-template-columns:minmax(260px,1fr) 180px 155px auto auto;gap:9px}.filters input,.filters select,.form input,.form select,.form textarea{width:100%;padding:10px;border:1px solid #bdcad5;border-radius:5px;font:inherit;background:#fff}.section-head{display:flex;justify-content:space-between;align-items:center}.section-head h2{margin:0}.table-wrap{overflow:auto}table{width:100%;border-collapse:collapse;margin-top:12px}th,td{text-align:left;padding:11px 9px;border-bottom:1px solid #e2e8ed;vertical-align:top}th{font-size:12px;color:#687989;background:#f7f9fb}.entry-title{width:55%}.entry-title a{color:#B30000;text-decoration:none}.entry-title small{display:block;margin-top:5px;color:#748391}.badge,.tag{display:inline-block;background:#e7eef5;color:#B30000;border-radius:12px;padding:4px 8px;font-size:11px}.empty{text-align:center;color:#71808d;padding:35px}.grid{display:grid;grid-template-columns:180px 220px minmax(280px,1fr);gap:13px}.grid label{font-weight:bold;font-size:12px}.grid label input,.grid label select{margin-top:6px;font-weight:normal}.grid .wide{grid-column:span 1}.links{grid-template-columns:1fr 1fr}.links .wide{grid-column:1/-1}.editor-block{margin:18px 0}.editor-head h2{font-size:17px}.toolbar{display:flex;gap:5px;flex-wrap:wrap;background:#f3f6f8;border:1px solid #cbd6df;border-bottom:0;padding:7px;border-radius:5px 5px 0 0}.toolbar button{border:1px solid #c0ccd6;background:#fff;border-radius:4px;padding:6px 8px;cursor:pointer}.editor-block textarea{border-radius:0 0 5px 5px!important;min-height:330px;line-height:1.5}.actions{display:flex;gap:8px}.inline{display:inline}.eyebrow{text-transform:uppercase;letter-spacing:.08em;color:#607b92;font-size:12px;font-weight:bold}.tag-row{margin-top:8px;display:flex;gap:5px}.content{font-family:Arial,sans-serif;line-height:1.58}.content h2,.content h3{color:#244d70;border-bottom:1px solid #dbe3ea;padding-bottom:5px}.content pre{background:#17222d;color:#eaf2f8;padding:14px;border-radius:5px;overflow:auto}.embedded-image{display:block;max-width:100%;height:auto;margin:12px auto;border-radius:4px}.text-blue{color:#145ca8}.text-red{color:#b52323}mark{background:#fff19b}.admonition{padding:11px 13px;border-left:4px solid #EC0000;background:#FFF4F4;margin:10px 0}.admonition.warning{border-color:#c58418;background:#fff7e5}.meta-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:10px}.meta-grid div{background:#f7f9fb;padding:12px;border-radius:5px}.meta-grid strong,.meta-grid span{display:block}.meta-grid span{margin-top:5px;color:#5e7080;word-break:break-word}.notice{padding:11px;margin:12px 0;background:#e9f6ec;border:1px solid #aed8b8;border-radius:5px;color:#245c31}.group-add-form{display:flex;gap:9px}.group-add-form input{flex:1;padding:10px;border:1px solid #bdcad5;border-radius:5px}.group-edit-form{display:flex;gap:7px;align-items:center}.group-edit-form input{min-width:220px;padding:8px;border:1px solid #bdcad5;border-radius:5px}.btn:disabled{opacity:.5;cursor:not-allowed}.comments-card{margin-top:18px}.comment-count{display:inline-flex;min-width:26px;height:26px;align-items:center;justify-content:center;border-radius:13px;background:#e7eef5;color:#B30000;font-weight:bold}.comments-list{margin:14px 0}.comment-item{padding:13px 0;border-top:1px solid #e1e7ec}.comment-item:first-child{border-top:0}.comment-meta{display:flex;justify-content:space-between;gap:12px;color:#607080;font-size:12px}.comment-meta form{margin:0}.comment-delete{border:0;background:transparent;color:#a53b3b;cursor:pointer;padding:0}.comment-text{margin-top:8px;line-height:1.5}.comment-text p{margin:0 0 7px}.comments-empty{color:#71808d;font-style:italic}.comment-form{border-top:1px solid #dfe6ec;padding-top:15px}.comment-form label{display:block;font-weight:bold}.comment-form textarea{display:block;width:100%;margin:7px 0 10px;padding:10px;border:1px solid #bdcad5;border-radius:5px;font:inherit;resize:vertical}@media(max-width:900px){.shell{grid-template-columns:1fr}aside{display:none}.filters,.grid,.links{grid-template-columns:1fr}.page-head{display:block}.page-head>div+div{margin-top:12px}}

/* V15.6 · Tipografía del editor unificada con Wiki */
.form label{font-size:12px}
.form input,.form select,.form textarea{font-size:12px;line-height:1.42}
.editor-head h2{font-size:15px}
.editor-block .toolbar{gap:5px;padding:6px 8px}
.editor-block .toolbar button{padding:5px 8px;font-size:12px;line-height:1.2}
.editor-block textarea{
  min-height:430px;
  padding:10px 12px;
  font-family:Consolas,"Courier New",monospace;
  font-size:14px;
  line-height:20px;
  tab-size:4;
}
.comment-form textarea{
  font-family:Arial,sans-serif;
  font-size:13px;
  line-height:1.42;
}

/* V16.0 · Escala documental única (pantalla) */
:root{
  --doc-font-family:Arial,sans-serif;
  --doc-text-size:12px;
  --doc-h4-size:12px;
  --doc-h3-size:13px;
  --doc-h2-size:14px;
  --doc-h1-size:15px;
  --doc-code-size:11px;
  --doc-heading-color:#202124;
  --doc-h1-color:#EC0000;
  --doc-line-height:1.6;
}
.meta,.doc-meta,.page-meta{
  font-size:var(--doc-text-size);
}
article,.document-preview article,.template-preview-panel article,.content,.viewer,.editor-preview{
  font-family:var(--doc-font-family);
  font-size:var(--doc-text-size);
  line-height:var(--doc-line-height);
}
article h1,.document-preview h1,.template-preview-panel h1,.content h1,.viewer h1,.editor-preview h1{
  margin:12px 0 7px;
  color:var(--doc-h1-color);
  font-size:var(--doc-h1-size);
  font-weight:700;
  line-height:1.3;
}
article h2,.document-preview h2,.template-preview-panel h2,.content h2,.viewer h2,.editor-preview h2{
  margin:11px 0 6px;
  color:var(--doc-heading-color);
  font-size:var(--doc-h2-size);
  font-weight:700;
  line-height:1.3;
}
article h3,.document-preview h3,.template-preview-panel h3,.content h3,.viewer h3,.editor-preview h3{
  margin:10px 0 5px;
  color:var(--doc-heading-color);
  font-size:var(--doc-h3-size);
  font-weight:700;
  line-height:1.3;
}
article h4,.document-preview h4,.template-preview-panel h4,.content h4,.viewer h4,.editor-preview h4{
  margin:9px 0 5px;
  color:var(--doc-heading-color);
  font-size:var(--doc-h4-size);
  font-weight:700;
  font-style:italic;
  line-height:1.3;
}
article p,article li,article td,article th,
.document-preview p,.document-preview li,.document-preview td,.document-preview th,
.template-preview-panel p,.template-preview-panel li,.template-preview-panel td,.template-preview-panel th,
.content p,.content li,.content td,.content th,.viewer p,.editor-preview p{
  font-size:var(--doc-text-size);
  line-height:var(--doc-line-height);
}
article p,.document-preview p,.template-preview-panel p,.content p,.viewer p,.editor-preview p{margin:6px 0}
article ul,article ol,.document-preview ul,.document-preview ol,.template-preview-panel ul,.template-preview-panel ol,.content ul,.content ol{margin:6px 0;padding-left:22px}
article pre,article pre code,.code-box,.code-box code,.document-preview pre,.document-preview pre code,.template-preview-panel pre,.template-preview-panel pre code,.content pre,.content pre code{
  font-family:Consolas,"Courier New",monospace;
  font-size:var(--doc-code-size);
  line-height:1.45;
}
article table,.document-preview table,.template-preview-panel table,.content table{width:100%;border-collapse:collapse;font-size:var(--doc-text-size)}
article th,article td,.document-preview th,.document-preview td,.template-preview-panel th,.template-preview-panel td,.content th,.content td{padding:6px 8px;border:1px solid #a2a9b1;text-align:left;vertical-align:top}
article th,.document-preview th,.template-preview-panel th,.content th{background:#eaecf0;font-weight:700}

.text-indent{white-space:pre;display:inline}

/* V19.4 · Espaciado semántico; no se aplica al código */
.content h1{margin:22px 0 8px;color:#145ca8;font-size:14px;font-weight:700}
.content h2{margin:18px 0 6px;font-size:13px;font-weight:700}
.content h3{margin:14px 0 5px;font-size:12px;font-weight:700}
.content h4{margin:10px 0 4px;font-size:11px;font-weight:400;font-style:italic}
.content>p{margin:0 0 8px;padding:0}
.content>p+p{margin-top:2px}
.content ul,.content ol{margin:7px 0 9px;padding-left:24px}
.content blockquote{margin:10px 0 10px 14px;padding:7px 11px}
.content .admonition{margin:10px 0 10px 14px}
.content pre,.content code{font-family:Consolas,"Courier New",monospace;text-indent:0;letter-spacing:normal;word-spacing:normal}
.content pre{margin:12px 0;white-space:pre;line-height:1.45}
.content pre code{white-space:pre}

'''

if __name__=='__main__': ThreadingHTTPServer(('127.0.0.1',int(os.environ.get('BITACORA_PORT','8083'))),Handler).serve_forever()
