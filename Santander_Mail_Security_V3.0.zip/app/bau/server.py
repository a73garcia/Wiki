from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs, quote
from pathlib import Path
from datetime import datetime
import os, json, html, re, uuid, mimetypes

CORPORATE_THEME_CSS = r""":root {
  --santander-red:#EC0000;
  --santander-red-dark:#C00000;
  --santander-red-deep:#990000;
  --santander-red-soft:#FDECEC;
  --santander-coral:#FF5A5F;
  --santander-orange:#F57C00;
  --santander-black:#111111;
  --santander-text:#2D2D2D;
  --santander-grey-700:#5B5B5B;
  --santander-grey-500:#8A8A8A;
  --santander-grey-300:#C9C9C9;
  --santander-grey-200:#E5E5E5;
  --santander-grey-100:#F2F2F2;
  --santander-bg:#F7F7F7;
  --santander-white:#FFFFFF;
  --brand-font:"Santander Headline","Segoe UI",Arial,sans-serif;
  --body-font:"Santander Headline","Segoe UI",Arial,sans-serif;
}
*{box-sizing:border-box}
html,body{font-family:var(--body-font)!important}
body{background:var(--santander-bg)!important;color:var(--santander-text)!important}
header{
  background:linear-gradient(105deg,var(--santander-red-dark),var(--santander-red))!important;
  color:#fff!important;border-bottom:0!important;box-shadow:0 3px 12px rgba(80,0,0,.18)!important;
}
.brand{font-family:var(--brand-font)!important;font-weight:600!important;letter-spacing:.1px!important;display:flex!important;align-items:center!important;gap:12px!important}
.brand::before{
  content:"";display:inline-block;width:36px;height:34px;flex:0 0 36px;
  background-image:url("/corporate-logo.png");
  background-size:contain;background-position:center;background-repeat:no-repeat;
  filter:brightness(0) invert(1);
}
.shell aside,aside{background:#fff!important;border-right:1px solid var(--santander-grey-200)!important}
aside nav a,nav a{color:#3c3c3c!important;border-radius:6px!important;transition:.15s ease!important}
aside nav a:hover,nav a:hover{background:var(--santander-red-soft)!important;color:var(--santander-red-dark)!important}
aside nav a.active,nav a.active{
  background:var(--santander-red-soft)!important;color:var(--santander-red-dark)!important;
  border-left:4px solid var(--santander-red)!important;font-weight:700!important;
}
main h1,main h2,.page-title{font-family:var(--brand-font)!important;color:var(--santander-red-dark)!important}
main h3{font-family:var(--brand-font)!important;color:var(--santander-black)!important}
a{color:var(--santander-red-dark)}
a:hover{color:var(--santander-red)}
.btn,.button,button,input[type=submit],input[type=button]{
  font-family:var(--body-font)!important;border-radius:6px!important;box-shadow:none!important;
}
.btn.primary,.btn-primary,.button-primary,button.primary,input[type=submit]{
  background:var(--santander-red)!important;border-color:var(--santander-red)!important;color:#fff!important;
}
.btn.primary:hover,.btn-primary:hover,button.primary:hover,input[type=submit]:hover{
  background:var(--santander-red-dark)!important;border-color:var(--santander-red-dark)!important;
}
.btn:not(.primary),button:not(.primary){
  background:#fff!important;border-color:var(--santander-grey-300)!important;color:var(--santander-text)!important;
}
.card,.panel,.widget,.stat,.tile,.project-card,.task-card,.wiki-card,.bau-card{
  background:#fff!important;border:1px solid var(--santander-grey-200)!important;
  border-radius:10px!important;box-shadow:0 2px 8px rgba(0,0,0,.045)!important;
}
table{background:#fff!important;border-color:var(--santander-grey-200)!important}
thead th,table th{background:var(--santander-red-dark)!important;color:#fff!important;border-color:var(--santander-red-dark)!important}
tbody tr:nth-child(even){background:#FAFAFA!important}
input,select,textarea{
  font-family:var(--body-font)!important;border:1px solid var(--santander-grey-300)!important;border-radius:6px!important;
}
input:focus,select:focus,textarea:focus{
  border-color:var(--santander-red)!important;outline:0!important;box-shadow:0 0 0 3px rgba(236,0,0,.12)!important;
}
.badge,.chip,.tag{border-radius:999px!important}
.badge.en-curso,.badge.alta,.badge.critica,.badge.crítica{background:var(--santander-red-soft)!important;color:var(--santander-red-dark)!important}
.notice,.alert,.callout{border-left:6px solid var(--santander-red)!important;background:#fff!important}
pre,code,.code-block{background:#F2F2F2!important;border-color:#D5D5D5!important}
footer{border-top:1px solid var(--santander-grey-200)!important;color:var(--santander-grey-700)!important}
@media print {
  header,aside,.header-actions,.actions,.toolbar,footer{display:none!important}
  body,main{background:#fff!important;color:#111!important}
  main{width:100%!important;max-width:none!important;margin:0!important;padding:0!important}
  h1,h2{color:var(--santander-red-dark)!important}
  table th{background:var(--santander-red-dark)!important;color:#fff!important;-webkit-print-color-adjust:exact;print-color-adjust:exact}
  .notice,.alert,.callout{border-left-color:var(--santander-red)!important;-webkit-print-color-adjust:exact;print-color-adjust:exact}
}
/* V25.2 — Cabecera corporativa: símbolo rojo íntegro sobre fondo blanco */
header{
  min-height:68px!important;
  height:auto!important;
  padding:10px 22px!important;
  background:#FFFFFF!important;
  color:#222222!important;
  border-bottom:4px solid #EC0000!important;
  box-shadow:0 2px 10px rgba(0,0,0,.08)!important;
  overflow:visible!important;
}
.brand{
  min-width:0!important;
  color:#222222!important;
  font-family:var(--brand-font,"Santander Headline","Segoe UI",Arial,sans-serif)!important;
  font-size:20px!important;
  line-height:1.15!important;
  font-weight:600!important;
  display:flex!important;
  align-items:center!important;
  gap:13px!important;
  white-space:nowrap!important;
  overflow:visible!important;
}
.brand::before{
  content:""!important;
  display:block!important;
  width:46px!important;
  height:46px!important;
  min-width:46px!important;
  max-width:46px!important;
  flex:0 0 46px!important;
  background-color:#FFFFFF!important;
  background-repeat:no-repeat!important;
  background-position:center!important;
  background-size:contain!important;
  border:0!important;
  border-radius:0!important;
  box-shadow:none!important;
}
@media(max-width:700px){
  header{min-height:60px!important;padding:8px 14px!important}
  .brand{font-size:17px!important;gap:10px!important}
  .brand::before{width:38px!important;height:38px!important;min-width:38px!important;max-width:38px!important;flex-basis:38px!important}
}

/* V25.3 — Auditoría de legibilidad y contraste */
:root{
  --accessible-text:#202124;
  --accessible-muted:#5F6368;
  --accessible-border:#AEB4BA;
  --accessible-link:#B30000;
  --accessible-focus:#8A0000;
  --code-bg:#1F2328;
  --code-head:#2D333B;
  --code-text:#F0F3F6;
  --code-muted:#B7C0CA;
  --code-keyword:#FF9A91;
  --code-string:#B6D7FF;
  --code-number:#91CBFF;
  --code-comment:#B7C0CA;
  --code-variable:#FFC07A;
  --code-builtin:#DFB6FF;
  --code-pipe:#FFD866;
}
body{color:var(--accessible-text)!important}
a{color:var(--accessible-link)!important}
a:hover,a:focus{text-decoration:underline!important;color:#8A0000!important}
small,.muted,.meta,.aside-note,.page-head p,.stats span,.stat span,.card-meta{
  color:var(--accessible-muted)!important;
  opacity:1!important;
}
button:focus-visible,a:focus-visible,input:focus-visible,select:focus-visible,textarea:focus-visible{
  outline:3px solid var(--accessible-focus)!important;
  outline-offset:2px!important;
}
input,select,textarea{
  color:#202124!important;
  background:#FFFFFF!important;
  border-color:#8A9097!important;
  opacity:1!important;
}
input::placeholder,textarea::placeholder{color:#656B72!important;opacity:1!important}
button:disabled,.btn:disabled{opacity:.65!important;color:#3C4043!important}

/* Código: contraste alto y sin transparencias */
.code-wrap,.code-block,.code-container,.editor-code{
  background:var(--code-bg)!important;
  border-color:#59636E!important;
  opacity:1!important;
}
.code-head,.code-header,.code-title{
  background:var(--code-head)!important;
  color:#FFFFFF!important;
  border-color:#59636E!important;
  opacity:1!important;
}
.code-box,.code-box code,pre,pre code,.content pre,.content pre code{
  background:var(--code-bg)!important;
  color:var(--code-text)!important;
  font-family:Consolas,"Courier New",monospace!important;
  font-size:14px!important;
  line-height:1.65!important;
  opacity:1!important;
  text-shadow:none!important;
  filter:none!important;
}
.code-box *,pre *,pre code *{
  opacity:1!important;
  text-shadow:none!important;
  filter:none!important;
}
.tok-keyword{color:var(--code-keyword)!important;font-weight:700!important}
.tok-string{color:var(--code-string)!important}
.tok-comment{color:var(--code-comment)!important;font-style:italic!important}
.tok-number{color:var(--code-number)!important}
.tok-builtin{color:var(--code-builtin)!important}
.tok-variable{color:var(--code-variable)!important}
.tok-operator{color:#FF9A91!important;font-weight:700!important}
.tok-pipe{color:var(--code-pipe)!important;font-weight:800!important}
.tok-key,.tok-tag{color:#9BE9A8!important}
.copy-code,.code-head button,.code-header button{
  background:#FFFFFF!important;
  color:#8A0000!important;
  border:1px solid #FFFFFF!important;
  font-weight:700!important;
}

/* Avisos: texto oscuro y fondos claros */
.admonition,.notice,.alert{
  color:#202124!important;
  opacity:1!important;
}
.admonition *,.notice *,.alert *{opacity:1!important}
.admonition.advertencia,.warning{
  background:#FFF4E5!important;
  border-color:#C54800!important;
  color:#3B2500!important;
}
.admonition.informacion,.admonition.nota,.info{
  background:#F3F6F9!important;
  border-color:#B30000!important;
  color:#202124!important;
}
.admonition.importante{
  background:#FDECEC!important;
  border-color:#B30000!important;
  color:#4A0000!important;
}
.admonition.error,.error{
  background:#FCE8E6!important;
  border-color:#A50E0E!important;
  color:#5F0000!important;
}

/* Tablas, tarjetas, etiquetas y estados */
th{background:#ECEFF1!important;color:#30343B!important}
td{color:#202124!important}
.card,section,.stat,.project-card,.info-card{
  color:#202124!important;
}
.badge,.tag{
  color:#30343B!important;
  opacity:1!important;
}
.status-en-curso,.badge.en-curso{background:#FFE1E1!important;color:#8A0000!important}
.status-finalizado,.status-completada,.badge.resuelta,.badge.cerrada{
  background:#DFF1E5!important;color:#1F5D36!important;
}
.status-bloqueada,.status-cancelado,.priority-critica,.badge.priority.critica{
  background:#F8D7DA!important;color:#721C24!important;
}
.primary,.btn.primary{
  background:#EC0000!important;color:#FFFFFF!important;border-color:#B30000!important;
}
.primary:hover,.btn.primary:hover{background:#B30000!important;color:#FFFFFF!important}

/* V25.4 — Selecciones legibles y zona de información ampliada */
html,body{width:100%;min-width:0}
.shell{
  width:calc(100% - 24px)!important;
  max-width:1920px!important;
  margin:0 auto!important;
  grid-template-columns:230px minmax(0,1fr)!important;
}
main{
  width:100%!important;
  max-width:none!important;
  min-width:0!important;
  margin:0!important;
  padding:20px 24px 36px!important;
}
main > *,article,.content,.page-content,.dashboard-grid{
  max-width:none!important;
}
article{width:100%!important}
.card,section,.hero,.panel{
  max-width:none!important;
}
.form-card,.editor,.github-editor,.info-card{
  max-width:none!important;
  width:100%!important;
}
.table-wrap,.pending-card,.pending-table{
  width:100%!important;
  max-width:none!important;
}
table{width:100%!important}

/* Filtros y pestañas: estados claramente visibles */
.pending-filters,.search-filters,.module-tabs{
  display:flex!important;
  flex-wrap:wrap!important;
  gap:8px!important;
  align-items:center!important;
}
.pending-filter,.search-filters a,.module-tabs a{
  display:inline-flex!important;
  align-items:center!important;
  justify-content:center!important;
  min-height:36px!important;
  padding:8px 14px!important;
  border:1px solid #B8BEC5!important;
  border-radius:999px!important;
  background:#FFFFFF!important;
  color:#9B0000!important;
  font-size:13px!important;
  line-height:1.2!important;
  font-weight:600!important;
  text-decoration:none!important;
  opacity:1!important;
  white-space:nowrap!important;
}
.pending-filter:hover,.search-filters a:hover,.module-tabs a:hover{
  background:#FDECEC!important;
  border-color:#EC0000!important;
  color:#780000!important;
  text-decoration:none!important;
}
.pending-filter.active,.search-filters a.active,.module-tabs a.active{
  background:#EC0000!important;
  border-color:#B30000!important;
  color:#FFFFFF!important;
  font-weight:700!important;
  box-shadow:0 0 0 1px #EC0000!important;
}
.pending-filter.active *,
.search-filters a.active *,
.module-tabs a.active *{
  color:#FFFFFF!important;
}

/* Tarjetas resumen */
.pending-summary{
  grid-template-columns:repeat(4,minmax(180px,1fr))!important;
  gap:12px!important;
}
.pending-chip{
  min-height:72px!important;
  padding:14px 16px!important;
  background:#FFFFFF!important;
  color:#30343B!important;
  border:1px solid #C7CDD3!important;
}
.pending-chip:hover{
  background:#FFF5F5!important;
  border-color:#EC0000!important;
  text-decoration:none!important;
}
.pending-chip strong{font-size:24px!important;color:#202124!important}

/* Ventanas y cuadros de información más amplios */
.import-dialog,.modal-dialog,.dialog,.popup,.detail-dialog{
  width:min(1100px,calc(100vw - 40px))!important;
  max-width:1100px!important;
  max-height:92vh!important;
}
.import-dialog-body,.modal-body,.dialog-body{
  padding:22px 24px!important;
}
.project-grid{
  grid-template-columns:repeat(auto-fit,minmax(280px,1fr))!important;
}
.detail-grid{
  grid-template-columns:repeat(2,minmax(0,1fr))!important;
}
.editor-row{
  grid-template-columns:repeat(2,minmax(0,1fr))!important;
}

@media(min-width:1600px){
  .shell{width:calc(100% - 32px)!important;max-width:2200px!important}
  main{padding:22px 30px 42px!important}
}
@media(max-width:1050px){
  .pending-summary{grid-template-columns:repeat(2,minmax(160px,1fr))!important}
  .detail-grid,.editor-row{grid-template-columns:1fr!important}
}
@media(max-width:850px){
  .shell{display:block!important;width:100%!important}
  main{padding:16px!important}
  .pending-summary{grid-template-columns:1fr!important}
  .pending-filter,.search-filters a,.module-tabs a{font-size:12px!important;padding:8px 12px!important}
}

/* V25.5 — Tipografía exacta para PDF */
@media print {
  html,body,main,article,.content,.page-content{
    font-size:12px!important;
    line-height:1.45!important;
  }

  p,li,dd,dt,td,th,span,div,label{
    font-size:12px!important;
  }

  h1,h2,h3,h4,h5,h6,
  .page-title,.section-title,.card-title{
    font-size:14px!important;
    line-height:1.25!important;
  }

  .email-example,
  .email-example *,
  .communication-email,
  .communication-email *,
  .communication-case,
  .communication-case *,
  .communication-response,
  .communication-response *,
  .case-field,
  .case-field *,
  .admonition,
  .admonition *,
  .notice,
  .notice *,
  .alert,
  .alert *,
  .callout,
  .callout *,
  .code-wrap,
  .code-wrap *,
  .code-box,
  .code-box *,
  .code-head,
  .code-head *,
  pre,
  pre *,
  code,
  code *{
    font-size:9px!important;
    line-height:1.4!important;
  }

  .email-example-title,
  .communication-title,
  .admonition-title,
  .code-head{
    font-size:9px!important;
    font-weight:700!important;
  }

  .email-example,
  .communication-email,
  .communication-case,
  .communication-response,
  .admonition,
  .notice,
  .alert,
  .callout,
  .code-wrap,
  pre{
    break-inside:avoid!important;
    page-break-inside:avoid!important;
  }
}
"""

BASE=Path(__file__).resolve().parent
DATA=BASE/'data'; DB=DATA/'requests.json'; STATIC=BASE/'static'; LEGACY_UPLOADS=DATA/'uploads'; UPLOADS=BASE.parent.parent/'imagenes'
DATA.mkdir(exist_ok=True); LEGACY_UPLOADS.mkdir(parents=True,exist_ok=True); UPLOADS.mkdir(parents=True,exist_ok=True)
for old_image in LEGACY_UPLOADS.iterdir():
    if old_image.is_file() and not (UPLOADS/old_image.name).exists():
        try:
            import shutil; shutil.copy2(old_image,UPLOADS/old_image.name)
        except OSError: pass
PORTAL_URL=os.environ.get('PORTAL_URL','http://127.0.0.1:8079')
WIKI_URL=os.environ.get('WIKI_URL','http://127.0.0.1:8080')
GESTOR_URL=os.environ.get('GESTOR_URL','http://127.0.0.1:8081')
BITACORA_URL=os.environ.get('BITACORA_URL','http://127.0.0.1:8083')
BIBLIOTECA_URL=os.environ.get('BIBLIOTECA_URL','http://127.0.0.1:8084')
CAMBIOS_URL=os.environ.get('CAMBIOS_URL','http://127.0.0.1:8085')
STATUSES=['Nueva','En curso','Pendiente','Resuelta','Cerrada']
PRIORITIES=['Baja','Media','Alta','Crítica']
TYPES=['Petición','Incidencia','Consulta','Cambio','Problema']
SYSTEMS=['Cisco ESA','Proofpoint','Splunk','CrowdStrike','Microsoft','Windows','Linux','Redes','Otro']

def esc(v): return html.escape(str(v or ''),quote=True)
def load():
    try:return json.loads(DB.read_text(encoding='utf-8')) if DB.exists() else []
    except Exception:return []
def save(rows): DB.write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8')
def now(): return datetime.now().isoformat(timespec='seconds')
def getone(rid): return next((x for x in load() if x.get('id')==rid),None)
def badge(v,kind=''): return f'<span class="badge {kind} {esc(v).lower().replace("í","i").replace("á","a").replace(" ","-")}">{esc(v)}</span>'
def options(values,current=''): return ''.join(f'<option {"selected" if x==current else ""}>{esc(x)}</option>' for x in values)

def inline_format(value):
    s=esc(value)
    s=re.sub(r'\[azul\](.*?)\[/azul\]',r'<span class="text-blue">\1</span>',s,flags=re.S|re.I)
    s=re.sub(r'\[rojo\](.*?)\[/rojo\]',r'<span class="text-red">\1</span>',s,flags=re.S|re.I)
    s=re.sub(r'\[amarillo\](.*?)\[/amarillo\]',r'<mark>\1</mark>',s,flags=re.S|re.I)
    s=re.sub(r'\*\*(.+?)\*\*',r'<strong>\1</strong>',s,flags=re.S)
    s=re.sub(r"''(.+?)''",r'<em>\1</em>',s,flags=re.S)
    s=re.sub(r'\[([^\]]+)\]\((https?://[^)]+)\)',r'<a href="\2" target="_blank" rel="noopener">\1</a>',s)
    return s

def render_leading_indent(raw_line, formatted_text):
    expanded=str(raw_line or '').expandtabs(4)
    leading=len(expanded)-len(expanded.lstrip(' '))
    return (('<span class="text-indent">'+('&#160;'*leading)+'</span>') if leading else '')+formatted_text

def render(text):
    lines=str(text or '').replace('\r\n','\n').split('\n')
    out=[]; paragraph=[]; list_tag=None; index=0

    def flush_paragraph():
        nonlocal paragraph
        if paragraph:
            out.append('<p>'+'<br>'.join(render_leading_indent(line, inline_format(line.lstrip().rstrip())) for line in paragraph)+'</p>')
            paragraph=[]

    def close_list():
        nonlocal list_tag
        if list_tag:
            out.append(f'</{list_tag}>')
            list_tag=None

    while index < len(lines):
        line=lines[index]
        stripped=line.strip()

        if stripped.startswith('```'):
            flush_paragraph(); close_list()
            language=stripped[3:].strip() or 'text'
            code=[]; index+=1
            while index < len(lines) and lines[index].strip()!='```':
                code.append(lines[index]); index+=1
            if index < len(lines): index+=1
            out.append(
                f'<div class="code-wrap"><div class="code-head"><span>{esc(language)}</span></div>'
                f'<pre class="code-box"><code class="language-{esc(language)}">'
                + html.escape('\n'.join(code))
                + '</code></pre></div>'
            )
            continue

        communication=re.fullmatch(r':::\s*(correo|email|caso|respuesta)(?:\s+(.+))?',stripped,re.I)
        if communication:
            flush_paragraph(); close_list()
            kind=communication.group(1).casefold()
            if kind=='email': kind='correo'
            title=(communication.group(2) or {'correo':'Correo','caso':'Caso','respuesta':'Respuesta'}[kind]).strip()
            block=[]; index+=1
            end_re=re.compile(rf':::\s*end(?:{re.escape(kind)}|correo|email|caso|respuesta)\s*$',re.I)
            while index < len(lines) and not end_re.fullmatch(lines[index].strip()):
                block.append(lines[index]); index+=1
            if index < len(lines): index+=1
            body='<br>'.join(inline_format(x) for x in block)
            out.append(f'<div class="communication {kind}"><div class="communication-title">{esc(title)}</div><div class="communication-body">{body}</div></div>')
            continue

        image=re.fullmatch(r'\[\[imagen:([^|\]]+)(?:\|([^\]]*))?\]\]',stripped)
        if image:
            flush_paragraph(); close_list()
            filename=image.group(1)
            description=image.group(2) or filename
            out.append(f'<img class="embedded-image" src="/uploads/{quote(filename)}" alt="{esc(description)}">')
            index+=1; continue

        heading=re.fullmatch(r'(={2,6})\s*(.*?)\s*\1',stripped)
        if heading:
            flush_paragraph(); close_list()
            level=min(len(heading.group(1)),6)
            out.append(f'<h{level}>{inline_format(heading.group(2))}</h{level}>')
            index+=1; continue

        # Sintaxis Wiki moderna:
        # !!! advertencia:
        # contenido
        # !!!
        notice_open=re.match(r'^!!!\s+(nota|advertencia|informacion|información)\s*:?\s*(.*)$',stripped,re.I)
        if notice_open:
            flush_paragraph(); close_list()
            kind=notice_open.group(1).casefold().replace('ó','o')
            trailing=notice_open.group(2).strip()
            block=[]; index+=1
            while index < len(lines) and lines[index].strip()!='!!!':
                block.append(lines[index]); index+=1
            if index < len(lines) and lines[index].strip()=='!!!':
                index+=1
            elif trailing:
                # Compatibilidad con avisos antiguos de una sola línea.
                block=[trailing]
            label={'advertencia':'Advertencia','nota':'Nota','informacion':'Información'}[kind]
            content='<br>'.join(inline_format(x) for x in block if x.strip())
            out.append(f'<div class="admonition {kind}"><strong>{label}</strong>{("<div>"+content+"</div>") if content else ""}</div>')
            continue

        bullet=re.match(r'^\s*[-*]\s+(.*)$',line)
        ordered=re.match(r'^\s*\d+\.\s+(.*)$',line)
        if bullet or ordered:
            flush_paragraph()
            wanted='ul' if bullet else 'ol'
            if list_tag != wanted:
                close_list(); out.append(f'<{wanted}>'); list_tag=wanted
            out.append('<li>'+inline_format((bullet or ordered).group(1))+'</li>')
            index+=1; continue

        if not stripped:
            flush_paragraph(); close_list(); index+=1; continue

        close_list(); paragraph.append(line); index+=1

    flush_paragraph(); close_list()
    return ''.join(out)

def layout(title,body,active='bau'):
    links=[('Inicio',PORTAL_URL),('Wiki',WIKI_URL),('Proyectos y tareas',GESTOR_URL),('BAU','/'),('Bitácora',BITACORA_URL),('Biblioteca',BIBLIOTECA_URL),('Plantillas',CAMBIOS_URL)]
    nav=''.join(f'<a class="{"active" if n.lower().startswith(active) else ""}" href="{esc(u)}">{esc(n)}</a>' for n,u in links)
    return f'''<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{esc(title)} · BAU</title><link rel="stylesheet" href="/static/style.css"><style>{CORPORATE_THEME_CSS}
/* V26.1: logotipo configurable desde configuracion/logo/logo.png */
.brand::before{{display:none!important;content:none!important;background-image:none!important}}
.brand .brand-logo{{
  display:block!important;width:46px!important;height:46px!important;
  min-width:46px!important;max-width:46px!important;flex:0 0 46px!important;
  object-fit:contain!important;object-position:center!important;
  background:transparent!important;border:0!important;border-radius:0!important;
  box-shadow:none!important
}}
.brand>span{{display:block!important}}
@media(max-width:760px){{
  .brand .brand-logo{{width:38px!important;height:38px!important;min-width:38px!important;max-width:38px!important;flex-basis:38px!important}}
}}
</style>
<style>
/* V27.3 · Logotipo adaptable al espacio disponible */
header{{
  min-height:72px!important;
  height:auto!important;
  overflow:visible!important;
}}
.brand{{
  min-height:56px!important;
  max-width:min(70vw,760px)!important;
  display:flex!important;
  align-items:center!important;
  gap:14px!important;
  overflow:visible!important;
}}
.brand::before{{
  display:none!important;
  content:none!important;
  background-image:none!important;
}}
.brand .brand-logo{{
  display:block!important;
  width:auto!important;
  height:auto!important;
  min-width:0!important;
  min-height:0!important;
  max-width:210px!important;
  max-height:56px!important;
  flex:0 1 auto!important;
  object-fit:contain!important;
  object-position:left center!important;
  background:transparent!important;
  border:0!important;
  border-radius:0!important;
  box-shadow:none!important;
}}
.brand>span{{
  display:block!important;
  min-width:0!important;
  overflow:hidden!important;
  text-overflow:ellipsis!important;
}}
@media(max-width:760px){{
  header{{min-height:64px!important;padding:8px 14px!important}}
  .brand{{min-height:46px!important;gap:10px!important;max-width:76vw!important}}
  .brand .brand-logo{{
    width:auto!important;
    height:auto!important;
    max-width:145px!important;
    max-height:46px!important;
  }}
}}
@media(max-width:480px){{
  .brand .brand-logo{{max-width:105px!important;max-height:42px!important}}
  .brand>span{{font-size:15px!important}}
}}
</style>

<style>
/* V27.7 · Logotipo ajustado al encabezado */
header{{min-height:58px!important;height:auto!important;padding:6px 16px!important;overflow:hidden!important}}
.brand{{min-height:44px!important;display:flex!important;align-items:center!important;gap:10px!important;max-width:min(64vw,700px)!important;overflow:hidden!important}}
.brand::before{{display:none!important;content:none!important}}
.brand .brand-logo{{display:block!important;width:auto!important;height:auto!important;max-width:150px!important;max-height:40px!important;min-width:0!important;min-height:0!important;flex:0 1 auto!important;object-fit:contain!important;object-position:left center!important}}
.brand>span{{min-width:0!important;overflow:hidden!important;text-overflow:ellipsis!important;white-space:nowrap!important}}
@media(max-width:760px){{.brand .brand-logo{{max-width:110px!important;max-height:36px!important}}.brand>span{{font-size:15px!important}}}}
</style>

<style>
/* V27.8 · Editor BAU agrupado como Wiki */
.wiki-style-toolbar{{display:flex!important;flex-wrap:wrap;gap:7px!important;align-items:center!important;padding:8px!important;background:#f7f7f7!important;border:1px solid #d8d8d8!important;border-radius:7px!important}}
.toolbar-main,.toolbar-groups{{display:flex;flex-wrap:wrap;gap:6px;align-items:center}}
.toolbar-groups{{border-left:1px solid #ccc;padding-left:7px}}
.toolbar-menu{{position:relative}}
.toolbar-menu summary{{list-style:none;cursor:pointer;border:1px solid #b8b8b8;background:#fff;border-radius:5px;padding:7px 10px;font-weight:600}}
.toolbar-menu summary::-webkit-details-marker{{display:none}}
.toolbar-menu-panel{{position:absolute;z-index:50;top:calc(100% + 4px);left:0;min-width:165px;background:#fff;border:1px solid #bbb;border-radius:7px;padding:6px;box-shadow:0 5px 18px rgba(0,0,0,.15);display:grid;gap:4px}}
.toolbar-menu-panel button{{width:100%;text-align:left}}
.communication{{margin:12px 0;border:1px solid #d5d5d5;border-left:5px solid #ec0000;border-radius:7px;background:#fff}}
.communication-title{{font-weight:700;background:#f5f5f5;padding:9px 12px;border-bottom:1px solid #ddd}}
.communication-body{{padding:12px;line-height:1.55}}
.communication.respuesta{{border-left-color:#007a3d}}
.communication.respuesta .communication-title{{background:#eaf6ef;color:#174d2e}}
.admonition{{margin:12px 0;padding:12px;border-left:5px solid #b30000;border-radius:6px}}
.admonition>div{{margin-top:6px}}
.admonition.advertencia{{background:#fff4e5;border-color:#c54800}}
.admonition.nota{{background:#f3f6f9;border-color:#b30000}}
.admonition.informacion{{background:#eaf3ff;border-color:#2563a7}}
.code-wrap{{margin:12px 0;border:1px solid #59636e;border-radius:7px;overflow:hidden}}
.code-head{{padding:7px 10px;background:#2d333b;color:#fff;font-weight:700}}
.code-box{{margin:0!important;border:0!important;border-radius:0!important}}
@media(max-width:800px){{.toolbar-groups{{border-left:0;padding-left:0}}.toolbar-menu-panel{{position:fixed;left:10%;right:10%;top:auto;min-width:0}}
</style>
</head><body><header><div class="brand"><img class="brand-logo" src="/logo.png?v=27112" alt="Logo Santander" onerror="this.style.display=\'none\'"><span>Santander Mail Security · BAU</span></div><div class="header-actions"><a class="btn" href="/">← Atrás</a><a class="btn" href="{esc(PORTAL_URL)}">Inicio común</a><a class="btn primary" href="/new">+ Nueva BAU</a></div></header><div class="shell"><aside><nav>{nav}</nav><div class="aside-note">Aplicación local<br>Sin usuarios<br>Datos en JSON</div></aside><main>{body}</main></div><script src="/static/editor.js"></script></body></html>'''

def dashboard(qs):
    rows=load()
    status=qs.get('status',[''])[0]
    term=qs.get('q',[''])[0].strip().casefold()
    period=qs.get('period',['all'])[0]
    if period not in ('all','today'):
        period='all'
    today=datetime.now().date().isoformat()
    filtered=[r for r in rows if (period!='today' or r.get('opened')==today) and (not status or r.get('status')==status) and (not term or term in ' '.join(str(r.get(k,'')) for k in ('number','title','request','investigation','resolution','system')).casefold())]
    filtered.sort(key=lambda x:x.get('opened',''),reverse=True)
    stats=''.join(f'<a class="stat" href="/?status={quote(s)}&period={quote(period)}"><strong>{sum(1 for r in rows if r.get("status")==s and (period!="today" or r.get("opened")==today))}</strong><span>{esc(s)}</span></a>' for s in STATUSES)
    trs=''.join(f'''<tr><td><a href="/view?id={esc(r['id'])}"><strong>{esc(r.get('number'))}</strong></a></td><td class="bau-title"><a href="/view?id={esc(r['id'])}">{esc(r.get('title'))}</a></td><td>{badge(r.get('type'))}</td><td>{badge(r.get('status'))}</td><td>{badge(r.get('priority'),'priority')}</td><td>{esc(r.get('system'))}</td><td>{esc(r.get('opened'))}</td></tr>''' for r in filtered) or '<tr><td colspan="7" class="empty">No hay registros.</td></tr>'
    period_options=f'<option value="all" {"selected" if period=="all" else ""}>Todas</option><option value="today" {"selected" if period=="today" else ""}>Solo hoy</option>'
    body=f'''<div class="page-head"><div><h1>Gestión BAU</h1><p>Control de peticiones, incidencias, consultas, cambios y problemas operativos.</p></div></div><div class="stats">{stats}</div><section class="card"><form class="filters bau-filters" method="get"><input name="q" value="{esc(qs.get('q',[''])[0])}" placeholder="Número, título, sistema, solicitud o resolución"><select name="period" aria-label="Periodo">{period_options}</select><select name="status"><option value="">Todos los estados</option>{options(STATUSES,status)}</select><button class="btn">Filtrar</button><a class="btn ghost" href="/">Limpiar</a></form></section><section class="card"><div class="section-head"><h2>Registros BAU</h2><a class="btn primary" href="/new">+ Nueva BAU</a></div><div class="table-wrap"><table class="bau-table"><colgroup><col class="col-number"><col class="col-title"><col class="col-type"><col class="col-status"><col class="col-priority"><col class="col-system"><col class="col-date"></colgroup><thead><tr><th>Número</th><th>Título</th><th>Tipo</th><th>Estado</th><th>Prioridad</th><th>Sistema</th><th>Fecha</th></tr></thead><tbody>{trs}</tbody></table></div></section>'''
    return layout('Gestión BAU',body)

def editor_field(label,name,value):
    return f'''<section class="editor-block">
    <div class="editor-head"><h2>{label}</h2></div>
    <div class="toolbar wiki-style-toolbar" data-target="{name}">
      <div class="toolbar-main">
        <button type="button" data-heading="2">Título</button>
        <button type="button" data-wrap="**">Negrita</button>
        <button type="button" data-wrap="''">Cursiva</button>
        <button type="button" data-wrap-open="[u]" data-wrap-close="[/u]">Subrayado</button>
        <button type="button" data-wrap-open="[azul]" data-wrap-close="[/azul]">Azul</button>
        <button type="button" data-wrap-open="[rojo]" data-wrap-close="[/rojo]">Rojo</button>
        <button type="button" data-wrap-open="[amarillo]" data-wrap-close="[/amarillo]">Resaltar</button>
        <button type="button" data-insert="- ">Lista</button>
        <button type="button" data-indent="1">→ Tab +4</button>
        <button type="button" data-outdent="1">← Quitar tab</button>
      </div>
      <div class="toolbar-groups">
        <details class="toolbar-menu">
          <summary>✉ Comunicación</summary>
          <div class="toolbar-menu-panel">
            <button type="button" data-communication="correo">Correo</button>
            <button type="button" data-communication="caso">Caso</button>
            <button type="button" data-communication="respuesta">Respuesta</button>
          </div>
        </details>
        <details class="toolbar-menu">
          <summary>⚠ Avisos</summary>
          <div class="toolbar-menu-panel">
            <button type="button" data-notice="nota">Nota</button>
            <button type="button" data-notice="advertencia">Advertencia</button>
            <button type="button" data-notice="informacion">Información</button>
          </div>
        </details>
        <details class="toolbar-menu">
          <summary>⌨ Código</summary>
          <div class="toolbar-menu-panel">
            <button type="button" data-code="spl">SPL</button>
            <button type="button" data-code="python">Python</button>
            <button type="button" data-code="text">Texto</button>
          </div>
        </details>
        <button type="button" data-image="1">🖼 Imagen</button>
      </div>
    </div>
    <textarea wrap="soft" id="{name}" name="{name}" rows="12">{esc(value)}</textarea>
    <input class="bau-image-input" data-editor="{name}" type="file" accept="image/*" hidden>
    <span class="upload-status" data-status="{name}"></span>
    </section>'''

def form_page(r=None):
    r=r or {}; editing=bool(r)
    body=f'''<div class="page-head"><div><h1>{'Editar' if editing else 'Nueva'} BAU</h1><p>La solicitud, investigación y resolución usan el mismo editor técnico de la Wiki.</p></div></div><form class="card form" method="post" action="/save"><input type="hidden" name="id" value="{esc(r.get('id'))}"><div class="grid"><label>Número de petición o incidencia<input name="number" value="{esc(r.get('number'))}" placeholder="Ej.: INC12345, RITM-00821 o SR-ABC-77" required maxlength="80"></label><label>Fecha apertura<input type="date" name="opened" value="{esc(r.get('opened') or datetime.now().date())}" required></label><label>Estado<select name="status">{options(STATUSES,r.get('status','Nueva'))}</select></label><label>Prioridad<select name="priority">{options(PRIORITIES,r.get('priority','Media'))}</select></label><label>Tipo<select name="type">{options(TYPES,r.get('type','Petición'))}</select></label><label>Sistema<select name="system">{options(SYSTEMS,r.get('system','Otro'))}</select></label></div><label>Título / breve descripción<input name="title" value="{esc(r.get('title'))}" required maxlength="180"></label>{editor_field('Solicitud','request',r.get('request',''))}{editor_field('Investigación','investigation',r.get('investigation',''))}{editor_field('Resolución','resolution',r.get('resolution',''))}<div class="actions"><button class="btn primary">Guardar BAU</button><a class="btn ghost" href="/">Cancelar</a></div></form>'''
    return layout('Editor BAU',body)

def section(title,text): return f'<section class="card content"><h2>{title}</h2>{render(text or "Sin información.")}</section>'
def view_page(r):
    comments=''.join(f'<li><strong>{esc(c.get("date"))}</strong><div>{render(c.get("text",""))}</div></li>' for c in reversed(r.get('comments',[]))) or '<li class="empty">Sin comentarios.</li>'
    body=f'''<div class="page-head"><div><div class="eyebrow">{esc(r.get('number'))}</div><h1>{esc(r.get('title'))}</h1><div class="badges">{badge(r.get('type'))}{badge(r.get('status'))}{badge(r.get('priority'),'priority')}{badge(r.get('system'))}</div></div><div><a class="btn" href="/edit?id={esc(r['id'])}">Editar</a> <form class="inline" method="post" action="/delete" onsubmit="return confirm('¿Eliminar esta BAU?')"><input type="hidden" name="id" value="{esc(r['id'])}"><button class="btn danger">Eliminar</button></form></div></div><div class="meta-grid"><div><strong>Fecha de apertura</strong><span>{esc(r.get('opened'))}</span></div><div><strong>Última actualización</strong><span>{esc(r.get('updated') or '—')}</span></div></div>{section('Solicitud',r.get('request'))}{section('Investigación',r.get('investigation'))}{section('Resolución',r.get('resolution'))}<section class="card"><h2>Seguimiento</h2><form method="post" action="/comment"><input type="hidden" name="id" value="{esc(r['id'])}"><textarea wrap="soft" name="text" rows="4" required placeholder="Añadir avance, respuesta, incidencia o decisión..."></textarea><button class="btn primary">Añadir comentario</button></form><ul class="timeline">{comments}</ul></section>'''
    return layout(r.get('number','BAU'),body)



def corporate_logo_path():
    """Devuelve siempre el logo corporativo de la carpeta raíz del proyecto."""
    source=Path(__file__).resolve()
    try:
        app_root=source.parents[2]
    except IndexError:
        app_root=source.parent
    candidates=[
        app_root/"configuracion"/"logo"/"logo.png",
        source.parent/"logo.png",
    ]
    for candidate in candidates:
        if candidate.is_file():
            return candidate
    return None

def serve_corporate_logo(handler):
    path = corporate_logo_path()
    if path is None:
        handler.send_response(404)
        handler.end_headers()
        return
    data = path.read_bytes()
    handler.send_response(200)
    handler.send_header("Content-Type", "image/png")
    handler.send_header("Content-Length", str(len(data)))
    handler.send_header("Cache-Control", "no-cache, no-store, must-revalidate")
    handler.end_headers()
    handler.wfile.write(data)

class Handler(BaseHTTPRequestHandler):
    def send_html(self,s,status=200):
        b=s.encode(); self.send_response(status); self.send_header('Content-Type','text/html; charset=utf-8'); self.send_header('Content-Length',str(len(b))); self.end_headers(); self.wfile.write(b)
    def send_json(self,value,status=200):
        b=json.dumps(value,ensure_ascii=False).encode('utf-8'); self.send_response(status); self.send_header('Content-Type','application/json; charset=utf-8'); self.send_header('Content-Length',str(len(b))); self.end_headers(); self.wfile.write(b)
    def redirect(self,u): self.send_response(303); self.send_header('Location',u); self.end_headers()
    def read_form(self):
        n=int(self.headers.get('Content-Length','0') or 0); return {k:v[-1] for k,v in parse_qs(self.rfile.read(n).decode('utf-8','replace'),keep_blank_values=True).items()}
    def multipart(self,max_size=15*1024*1024):
        ct=self.headers.get('Content-Type',''); m=re.search(r'boundary="?([^";]+)',ct); n=int(self.headers.get('Content-Length','0') or 0)
        if not m or n<=0 or n>max_size:return {},[]
        raw=self.rfile.read(n); boundary=('--'+m.group(1)).encode(); fields={}; files=[]
        for part in raw.split(boundary):
            if b'\r\n\r\n' not in part: continue
            head,body=part.split(b'\r\n\r\n',1); body=body.rstrip(b'\r\n-'); nm=re.search(br'name="([^"]+)"',head)
            if not nm: continue
            name=nm.group(1).decode('utf-8','replace'); fm=re.search(br'filename="([^"]*)"',head)
            if fm:
                fn=Path(fm.group(1).decode('utf-8','replace')).name
                if fn: files.append((name,fn,body))
            else: fields[name]=body.decode('utf-8','replace')
        return fields,files
    def do_GET(self):
        u=urlparse(self.path); qs=parse_qs(u.query)
        if u.path in {"/logo.png", "/corporate-logo.png"}: return serve_corporate_logo(self)
        if u.path=='/': return self.send_html(dashboard(qs))
        if u.path=='/new': return self.send_html(form_page())
        if u.path in ('/view','/edit'):
            r=getone(qs.get('id',[''])[0])
            if not r:return self.send_error(404)
            return self.send_html(form_page(r) if u.path=='/edit' else view_page(r))
        if u.path.startswith('/static/'):
            p=(STATIC/u.path.removeprefix('/static/')).resolve()
            if STATIC.resolve() not in p.parents or not p.is_file(): return self.send_error(404)
            b=p.read_bytes(); self.send_response(200); self.send_header('Content-Type',mimetypes.guess_type(p)[0] or 'application/octet-stream'); self.send_header('Content-Length',str(len(b))); self.end_headers(); return self.wfile.write(b)
        if u.path.startswith('/uploads/'):
            p=(UPLOADS/Path(u.path).name).resolve()
            if UPLOADS.resolve() not in p.parents or not p.is_file():return self.send_error(404)
            b=p.read_bytes(); self.send_response(200); self.send_header('Content-Type',mimetypes.guess_type(p)[0] or 'application/octet-stream'); self.send_header('Content-Length',str(len(b))); self.end_headers(); return self.wfile.write(b)
        self.send_error(404)
    def do_POST(self):
        u=urlparse(self.path)
        if u.path=='/upload-image':
            _,files=self.multipart()
            if not files:return self.send_json({'ok':False,'error':'No se recibió ninguna imagen.'},400)
            _,fn,data=files[0]; ext=Path(fn).suffix.lower()
            if ext not in ('.png','.jpg','.jpeg','.gif','.webp'):return self.send_json({'ok':False,'error':'Formato no permitido.'},400)
            stored=f'{uuid.uuid4().hex}{ext}'; (UPLOADS/stored).write_bytes(data)
            return self.send_json({'ok':True,'filename':stored})
        if u.path=='/save':
            f=self.read_form(); rows=load(); rid=f.get('id') or uuid.uuid4().hex; old=next((x for x in rows if x.get('id')==rid),{})
            r={**old,**{k:f.get(k,'').strip() for k in ('number','opened','status','priority','type','system','title','request','investigation','resolution')}}
            if not r.get('number'): return self.send_html(layout('Número obligatorio','<section class="card"><h1>Falta el número</h1><p>Introduce manualmente el número de petición o incidencia.</p><a class="btn" href="javascript:history.back()">Volver</a></section>'),400)
            r['id']=rid; r['created']=old.get('created') or now(); r['updated']=now(); r.setdefault('comments',[])
            rows=[x for x in rows if x.get('id')!=rid]+[r]; save(rows); return self.redirect('/view?id='+rid)
        f=self.read_form(); rid=f.get('id',''); rows=load(); r=next((x for x in rows if x.get('id')==rid),None)
        if u.path=='/comment' and r:
            r.setdefault('comments',[]).append({'date':now(),'text':f.get('text','').strip()}); r['updated']=now(); save(rows); return self.redirect('/view?id='+rid)
        if u.path=='/delete':
            save([x for x in rows if x.get('id')!=rid]); return self.redirect('/')
        self.send_error(404)
    def log_message(self,*args): pass

if __name__=='__main__': ThreadingHTTPServer(('127.0.0.1',int(os.environ.get('BAU_PORT','8082'))),Handler).serve_forever()
